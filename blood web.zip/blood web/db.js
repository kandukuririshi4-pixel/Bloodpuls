/**
 * BloodPulse Database Engine
 * Persistent file-backed JSON database with ACID-like safe disk synchronizations
 */

import fs from 'fs';
import path from 'path';
import {
  COMPATIBILITY_RULES,
  INVENTORY_STATUS_DATA,
  INITIAL_BLOOD_BANKS,
  INITIAL_REQUESTS,
  INITIAL_DONORS,
  HOSPITALS_LIST
} from './data.js';

const DB_FILE = path.join(import.meta.dirname, 'database.json');

class DatabaseEngine {
  constructor() {
    this.data = null;
    this.init();
  }

  getDefaultSeed() {
    return {
      bloodBanks: JSON.parse(JSON.stringify(INITIAL_BLOOD_BANKS)),
      requests: JSON.parse(JSON.stringify(INITIAL_REQUESTS)),
      donors: JSON.parse(JSON.stringify(INITIAL_DONORS)),
      hospitals: JSON.parse(JSON.stringify(HOSPITALS_LIST)),
      inventoryPredictions: JSON.parse(JSON.stringify(INVENTORY_STATUS_DATA)),
      notifications: [
        {
          id: 1,
          title: 'Emergency Dispatch Active',
          message: 'Courier Vikram Joshi en route with 2 units O- to Mercy Hospital.',
          time: '5m ago',
          type: 'amber',
          timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString()
        },
        {
          id: 2,
          title: 'Temperature Calibrated',
          message: 'Cold-Chain Unit #14 reports box temperature steady at 3.6°C.',
          time: '12m ago',
          type: 'green',
          timestamp: new Date(Date.now() - 12 * 60 * 1000).toISOString()
        },
        {
          id: 3,
          title: 'Inventory Synchronized',
          message: 'City Care Blood Bank refreshed morning stock counts.',
          time: '20m ago',
          type: 'blue',
          timestamp: new Date(Date.now() - 20 * 60 * 1000).toISOString()
        }
      ],
      auditLogs: [
        {
          id: 'log-1',
          timestamp: new Date().toISOString(),
          actor: 'System Bootstrap',
          action: 'DB_INITIALIZED',
          details: 'Initialized BloodPulse persistent storage engine'
        }
      ]
    };
  }

  init() {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        this.data = JSON.parse(raw);
        // Ensure all required collections exist
        if (!this.data.bloodBanks) this.data.bloodBanks = INITIAL_BLOOD_BANKS;
        if (!this.data.requests) this.data.requests = INITIAL_REQUESTS;
        if (!this.data.donors) this.data.donors = INITIAL_DONORS;
        if (!this.data.hospitals) this.data.hospitals = HOSPITALS_LIST;
        if (!this.data.inventoryPredictions) this.data.inventoryPredictions = INVENTORY_STATUS_DATA;
        if (!this.data.notifications) this.data.notifications = [];
        if (!this.data.auditLogs) this.data.auditLogs = [];
      } else {
        this.data = this.getDefaultSeed();
        this.persist();
      }
    } catch (err) {
      console.error('Error loading database.json, re-seeding with defaults:', err);
      this.data = this.getDefaultSeed();
      this.persist();
    }
  }

  persist() {
    try {
      const tempPath = `${DB_FILE}.tmp`;
      fs.writeFileSync(tempPath, JSON.stringify(this.data, null, 2), 'utf-8');
      fs.renameSync(tempPath, DB_FILE);
    } catch (err) {
      console.error('Critical: Failed to persist database:', err);
    }
  }

  reset() {
    this.data = this.getDefaultSeed();
    this.persist();
    return this.data;
  }

  // --- Audit & Notifications ---
  addAudit(actor, action, details) {
    const entry = {
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      actor: actor || 'Anonymous User',
      action,
      details
    };
    this.data.auditLogs.unshift(entry);
    if (this.data.auditLogs.length > 100) this.data.auditLogs.pop();
    this.persist();
    return entry;
  }

  addNotification(title, message, type = 'blue') {
    const notif = {
      id: Date.now(),
      title,
      message,
      time: 'Just now',
      type,
      timestamp: new Date().toISOString()
    };
    this.data.notifications.unshift(notif);
    if (this.data.notifications.length > 50) this.data.notifications.pop();
    this.persist();
    return notif;
  }

  getNotifications() {
    return this.data.notifications;
  }

  getAuditLogs() {
    return this.data.auditLogs;
  }

  // --- Overview Stats ---
  getStats() {
    let totalBloodUnits = 0;
    this.data.bloodBanks.forEach(b => {
      Object.values(b.inventory || {}).forEach(inv => {
        totalBloodUnits += (inv.units || 0);
      });
    });

    const activeBloodBanks = this.data.bloodBanks.length;
    const completedOrActiveDeliveries = this.data.requests.length;
    const totalDonors = this.data.donors.length;
    const emergencyCount = this.data.requests.filter(r => r.urgency === 'EMERGENCY').length;
    const pendingDeliveries = this.data.requests.filter(r => r.stageIndex < 5).length;

    return {
      totalBloodUnits: Math.max(248, totalBloodUnits),
      activeBloodBanks: Math.max(32, activeBloodBanks),
      completedOrActiveDeliveries: Math.max(156, completedOrActiveDeliveries + 153),
      totalDonors,
      emergencyCount,
      pendingDeliveries,
      actualUnitsInStock: totalBloodUnits,
      actualRequestCount: completedOrActiveDeliveries
    };
  }

  // --- Blood Banks ---
  getBanks(query = {}) {
    let banks = [...this.data.bloodBanks];

    if (query.search) {
      const q = query.search.toLowerCase();
      banks = banks.filter(b => b.name.toLowerCase().includes(q) || b.address.toLowerCase().includes(q));
    }

    if (query.maxDist) {
      const maxD = parseFloat(query.maxDist);
      if (!isNaN(maxD)) {
        banks = banks.filter(b => b.distanceKm <= maxD);
      }
    }

    if (query.group && query.group !== 'ALL') {
      banks = banks.filter(b => b.inventory && b.inventory[query.group] && b.inventory[query.group].units > 0);
    }

    if (query.component && query.component !== 'ALL') {
      banks = banks.filter(b => {
        return Object.values(b.inventory || {}).some(inv => inv.component === query.component);
      });
    }

    return banks;
  }

  getBankById(id) {
    return this.data.bloodBanks.find(b => b.id === id);
  }

  updateBankInventory(bankId, group, units, component, user = 'Bank Admin') {
    const bank = this.getBankById(bankId);
    if (!bank) return null;

    if (!bank.inventory) bank.inventory = {};
    bank.inventory[group] = {
      units: Math.max(0, parseInt(units) || 0),
      component: component || (bank.inventory[group]?.component || 'Packed RBC'),
      lastRefreshed: 'Just now'
    };

    let totalAvail = 0;
    Object.values(bank.inventory).forEach(inv => totalAvail += (inv.units || 0));
    bank.totalAvailable = totalAvail;
    bank.lastUpdated = 'Just now';

    this.addAudit(user, 'UPDATE_INVENTORY', `Updated ${bank.name} ${group} to ${units} units (${component})`);
    this.addNotification('Stock Updated', `${bank.name} inventory adjusted: ${group} now at ${units} units.`, 'blue');
    this.recalculatePredictions();
    this.persist();
    return bank;
  }

  adjustBankStock(bankId, group, delta, user = 'Bank Admin') {
    const bank = this.getBankById(bankId);
    if (!bank || !bank.inventory || !bank.inventory[group]) return null;

    const currentUnits = bank.inventory[group].units || 0;
    const newUnits = Math.max(0, currentUnits + delta);
    bank.inventory[group].units = newUnits;
    bank.inventory[group].lastRefreshed = 'Just now';

    let totalAvail = 0;
    Object.values(bank.inventory).forEach(inv => totalAvail += (inv.units || 0));
    bank.totalAvailable = totalAvail;
    bank.lastUpdated = 'Just now';

    this.addAudit(user, 'ADJUST_STOCK', `${delta > 0 ? '+' : ''}${delta} units for ${bank.name} (${group}), new total: ${newUnits}`);
    this.recalculatePredictions();
    this.persist();
    return { bank, group, newUnits };
  }

  // --- Smart Matching Algorithm ---
  smartMatch(bloodGroup, maxDist = 50, urgency = 'STANDARD') {
    const compatibleDonors = COMPATIBILITY_RULES[bloodGroup] || [bloodGroup];
    const matches = [];

    this.data.bloodBanks.forEach(bank => {
      if (bank.distanceKm > maxDist) return;

      const directUnits = bank.inventory[bloodGroup] ? bank.inventory[bloodGroup].units : 0;
      let totalCompatibleUnits = 0;

      compatibleDonors.forEach(donorGroup => {
        if (bank.inventory[donorGroup]) {
          totalCompatibleUnits += bank.inventory[donorGroup].units;
        }
      });

      if (totalCompatibleUnits > 0 || directUnits > 0) {
        const compatibilityScore = directUnits > 0 ? 100 : 75;
        const stockScore = Math.min(100, directUnits * 10);
        const distanceScore = Math.max(20, 100 - (bank.distanceKm * 8));

        let urgencyBoost = urgency === 'EMERGENCY' ? (15 / (bank.distanceKm + 1)) : 0;
        let finalMatchScore = Math.min(99, Math.round((compatibilityScore * 0.4) + (stockScore * 0.3) + (distanceScore * 0.3) + urgencyBoost));

        matches.push({
          bank,
          directUnits,
          totalCompatibleUnits,
          matchScore: finalMatchScore,
          primaryComponent: bank.inventory[bloodGroup]?.component || 'Packed RBC',
          lastRefreshed: bank.inventory[bloodGroup]?.lastRefreshed || '5 minutes ago'
        });
      }
    });

    matches.sort((a, b) => b.matchScore - a.matchScore);
    return matches;
  }

  // --- Requests / Requisitions ---
  getRequests(query = {}) {
    let list = [...this.data.requests];
    if (query.urgency) {
      list = list.filter(r => r.urgency === query.urgency.toUpperCase());
    }
    if (query.status) {
      list = list.filter(r => r.status === query.status.toUpperCase());
    }
    if (query.bloodBankId) {
      list = list.filter(r => r.bloodBankId === query.bloodBankId);
    }
    return list;
  }

  getRequestById(id) {
    return this.data.requests.find(r => r.id === id);
  }

  createRequest(payload, user = 'Hospital Requester') {
    const isEmergency = (payload.urgency || '').toUpperCase() === 'EMERGENCY';
    const bloodGroup = payload.bloodGroup || 'O-';
    const units = parseInt(payload.units) || (isEmergency ? 2 : 1);
    const component = payload.component || 'Packed RBC';

    let targetBank = null;
    if (payload.bloodBankId) {
      targetBank = this.getBankById(payload.bloodBankId);
    }

    if (!targetBank) {
      const matches = this.smartMatch(bloodGroup, 50, isEmergency ? 'EMERGENCY' : 'STANDARD');
      targetBank = matches.length > 0 ? matches[0].bank : this.data.bloodBanks[0];
    }

    // Deduct stock if available
    if (targetBank.inventory && targetBank.inventory[bloodGroup]) {
      targetBank.inventory[bloodGroup].units = Math.max(0, (targetBank.inventory[bloodGroup].units || 0) - units);
      targetBank.inventory[bloodGroup].lastRefreshed = 'Just now';
    }

    const reqId = `REQ-${Math.floor(1000 + Math.random() * 9000)}`;
    const otp = `${isEmergency ? 'EM' : 'BL'}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newReq = {
      id: reqId,
      patientName: payload.patientName || 'Emergency Admission',
      hospitalName: payload.hospitalName || 'Mercy General Hospital - Trauma ICU',
      bloodGroup,
      units,
      component,
      urgency: isEmergency ? 'EMERGENCY' : (payload.urgency || 'STANDARD'),
      reason: payload.reason || (isEmergency ? 'Acute trauma resuscitation protocol' : 'Scheduled requisition'),
      bloodBankId: targetBank.id,
      bloodBankName: targetBank.name,
      requestedTime: 'Just now',
      stageIndex: isEmergency ? 1 : 0,
      status: isEmergency ? 'VERIFICATION' : 'REQUESTED',
      courierName: isEmergency ? 'Rahul Verma (Express Rapid Fleet #02)' : 'Arjun Das (Medical Transit Fleet #09)',
      courierPhone: isEmergency ? '+1 (555) 777-8899' : '+1 (555) 443-8899',
      courierVehicle: isEmergency ? 'Emergency Priority EV Van #B-101' : 'Insulated Courier Transit Van #T-204',
      boxTemperature: isEmergency ? '3.4°C (Optimal Safe 2-6°C)' : '3.8°C (Optimal Safe 2-6°C)',
      etaMinutes: isEmergency ? 14 : 26,
      distanceRemainingKm: targetBank.distanceKm || 3.2,
      verificationCode: otp,
      timeline: [
        {
          step: 'REQUESTED',
          time: 'Just now',
          done: true,
          note: isEmergency ? 'Fast-track emergency protocol logged' : `Requisition created by ${payload.doctor || 'Attending Physician'}`
        },
        {
          step: 'VERIFICATION',
          time: isEmergency ? 'In progress' : 'Pending',
          done: isEmergency,
          note: isEmergency ? `Cross-match serology running at ${targetBank.name}` : 'Awaiting lab validation'
        },
        { step: 'APPROVED', time: 'Pending', done: false, note: 'Blood bank sign-off' },
        { step: 'BLOOD PACKED', time: 'Pending', done: false, note: 'Thermal container sealing' },
        { step: 'OUT FOR DELIVERY', time: 'Pending', done: false, note: 'Courier departure with live GPS' },
        { step: 'DELIVERED', time: 'Pending', done: false, note: 'Ward receipt & OTP confirmation' }
      ]
    };

    this.data.requests.unshift(newReq);

    const logMsg = `${newReq.urgency} Request ${reqId} for ${units}x ${bloodGroup} at ${newReq.hospitalName}`;
    this.addAudit(user, 'CREATE_REQUEST', logMsg);
    this.addNotification(
      isEmergency ? '🚨 Emergency Request Dispatched' : 'New Blood Requisition',
      `${newReq.patientName} (${bloodGroup}) allocated to ${targetBank.name}.`,
      isEmergency ? 'amber' : 'blue'
    );

    this.recalculatePredictions();
    this.persist();
    return newReq;
  }

  updateRequestStage(id, action = 'advance', targetIndex = null, user = 'Delivery Fleet') {
    const req = this.getRequestById(id);
    if (!req) return null;

    const stages = ['REQUESTED', 'VERIFICATION', 'APPROVED', 'BLOOD PACKED', 'OUT FOR DELIVERY', 'DELIVERED'];

    if (action === 'reset') {
      req.stageIndex = 0;
      req.status = 'REQUESTED';
      req.etaMinutes = 28;
      req.distanceRemainingKm = 4.2;
      req.timeline.forEach((step, idx) => {
        step.done = idx === 0;
        if (idx > 0) step.time = 'Pending';
      });
      this.addAudit(user, 'RESET_DELIVERY', `Reset transit simulation for ${id}`);
    } else if (action === 'set' && targetIndex !== null) {
      req.stageIndex = Math.max(0, Math.min(5, targetIndex));
      req.status = stages[req.stageIndex];
      if (req.stageIndex === 5) {
        req.etaMinutes = 0;
        req.distanceRemainingKm = 0;
      }
      this.addAudit(user, 'SET_STAGE', `Set stage of ${id} to ${req.status}`);
    } else if (action === 'advance') {
      if (req.stageIndex < 5) {
        req.stageIndex += 1;
        req.status = stages[req.stageIndex];

        // Mark timeline
        if (req.timeline && req.timeline[req.stageIndex]) {
          req.timeline[req.stageIndex].done = true;
          req.timeline[req.stageIndex].time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        }

        if (req.stageIndex === 5) {
          req.etaMinutes = 0;
          req.distanceRemainingKm = 0;
          this.addNotification('Delivery Fulfilled! 🎉', `Requisition ${req.id} delivered safely to ${req.hospitalName}`, 'green');
        } else {
          req.etaMinutes = Math.max(2, req.etaMinutes - 6);
          req.distanceRemainingKm = Math.max(0.3, parseFloat((req.distanceRemainingKm * 0.6).toFixed(1)));
        }

        this.addAudit(user, 'ADVANCE_STAGE', `Advanced ${id} to ${req.status} (ETA: ${req.etaMinutes}m)`);
      }
    }

    this.persist();
    return req;
  }

  // --- Donors ---
  getDonors(query = {}) {
    let donors = [...this.data.donors];
    if (query.bloodGroup && query.bloodGroup !== 'ALL') {
      donors = donors.filter(d => d.bloodGroup === query.bloodGroup);
    }
    if (query.city) {
      donors = donors.filter(d => d.city.toLowerCase().includes(query.city.toLowerCase()));
    }
    return donors;
  }

  createDonor(payload, user = 'Donor Self-Registration') {
    const donorId = `DON-${Math.floor(100 + Math.random() * 900)}`;
    const newDonor = {
      id: donorId,
      name: payload.name || 'Anonymous Donor',
      bloodGroup: payload.bloodGroup || 'O+',
      age: parseInt(payload.age) || 25,
      gender: payload.gender || 'Volunteer',
      lastDonationDate: 'First Registration',
      totalDonations: 0,
      eligibilityStatus: 'Eligible Today',
      city: payload.city || 'Central District',
      phone: payload.phone || '+1 (555) 000-0000',
      registeredAt: new Date().toISOString()
    };

    this.data.donors.unshift(newDonor);
    this.addAudit(user, 'REGISTER_DONOR', `Registered volunteer donor ${newDonor.name} (${newDonor.bloodGroup})`);
    this.addNotification('New Volunteer Donor', `${newDonor.name} registered Digital Life Pass for ${newDonor.bloodGroup}`, 'green');
    this.persist();
    return newDonor;
  }

  // --- Hospitals ---
  getHospitals() {
    return this.data.hospitals;
  }

  // --- Predictions & Real-time ML Recalculation ---
  getPredictions() {
    return this.data.inventoryPredictions;
  }

  recalculatePredictions() {
    // Dynamic analytics: count units in stock per blood group across all banks
    const stockPerGroup = {};
    const groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
    groups.forEach(g => stockPerGroup[g] = 0);

    this.data.bloodBanks.forEach(b => {
      Object.entries(b.inventory || {}).forEach(([grp, inv]) => {
        if (stockPerGroup[grp] !== undefined) {
          stockPerGroup[grp] += (inv.units || 0);
        }
      });
    });

    // Count open requests per blood group
    const requestDemand = {};
    groups.forEach(g => requestDemand[g] = 0);
    this.data.requests.forEach(r => {
      if (r.stageIndex < 5 && requestDemand[r.bloodGroup] !== undefined) {
        requestDemand[r.bloodGroup] += (r.units || 1);
      }
    });

    const updated = {};
    groups.forEach(grp => {
      const units = stockPerGroup[grp];
      const demand = requestDemand[grp];
      let status = 'Normal';
      let badgeType = 'status-normal';
      let stockTrend = 'Balanced';
      let safetyDays = 8;
      let demandIndex = 65;

      if (units <= 12 || demand >= 3) {
        status = 'Low Stock';
        badgeType = 'status-low';
        stockTrend = 'Urgent Reserves Only';
        safetyDays = Math.max(1, (units * 0.4).toFixed(1));
        demandIndex = Math.min(99, 80 + demand * 5);
      } else if (units < 25 || demand >= 1) {
        status = 'High Demand';
        badgeType = 'status-high';
        stockTrend = '+15% intake surge';
        safetyDays = Math.max(3, (units * 0.35).toFixed(1));
        demandIndex = Math.min(96, 75 + demand * 6);
      } else {
        status = 'Normal';
        badgeType = 'status-normal';
        stockTrend = '+4% this week';
        safetyDays = Math.max(7, (units * 0.4).toFixed(1));
        demandIndex = Math.min(75, 45 + demand * 4);
      }

      updated[grp] = {
        status,
        badgeType,
        demandIndex,
        stockTrend,
        safetyDays,
        currentStock: units,
        activeDemand: demand
      };
    });

    this.data.inventoryPredictions = updated;
    return updated;
  }
}

export const db = new DatabaseEngine();
