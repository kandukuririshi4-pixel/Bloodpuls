/**
 * BloodPulse Enterprise Node.js Backend Server & REST API Engine
 * Native high-performance HTTP server with Zero-Dependency Architecture.
 */

import http from 'http';
import fs from 'fs';
import path from 'path';
import { db } from './db.js';

const PORT = process.env.PORT || 3000;
const BASE_DIR = import.meta.dirname;

const MIME_TYPES = {
  '.html': 'text/html; charset=UTF-8',
  '.css': 'text/css; charset=UTF-8',
  '.js': 'application/javascript; charset=UTF-8',
  '.json': 'application/json; charset=UTF-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon'
};

function setCorsHeaders(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
}

function sendJSON(res, statusCode, payload) {
  setCorsHeaders(res);
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=UTF-8',
    'Cache-Control': 'no-cache'
  });
  res.end(JSON.stringify(payload));
}

function sendError(res, statusCode, message, details = null) {
  sendJSON(res, statusCode, {
    success: false,
    error: message,
    details,
    timestamp: new Date().toISOString()
  });
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 5 * 1024 * 1024) { // 5MB limit
        reject(new Error('Request payload too large'));
      }
    });
    req.on('end', () => {
      if (!body.trim()) {
        resolve({});
        return;
      }
      try {
        const parsed = JSON.parse(body);
        resolve(parsed);
      } catch (err) {
        reject(new Error('Invalid JSON in request body'));
      }
    });
    req.on('error', reject);
  });
}

// REST API Request Router
async function handleApiRequest(req, res, pathname, searchParams) {
  const method = req.method.toUpperCase();
  const query = Object.fromEntries(searchParams.entries());

  try {
    // 1. Health check & Diagnostics
    if (pathname === '/api/health' && method === 'GET') {
      return sendJSON(res, 200, {
        success: true,
        status: 'healthy',
        service: 'BloodPulse Core API',
        uptimeSeconds: Math.round(process.uptime()),
        timestamp: new Date().toISOString(),
        version: '2.0.0'
      });
    }

    // 2. Overview Stats Counter
    if (pathname === '/api/stats' && method === 'GET') {
      const stats = db.getStats();
      return sendJSON(res, 200, { success: true, data: stats });
    }

    // 3. Blood Banks & Inventory Endpoints
    // GET /api/banks
    if (pathname === '/api/banks' && method === 'GET') {
      const banks = db.getBanks(query);
      return sendJSON(res, 200, { success: true, count: banks.length, data: banks });
    }

    // Match bank by id: /api/banks/:id
    const bankMatch = pathname.match(/^\/api\/banks\/([a-zA-Z0-9_-]+)$/);
    if (bankMatch && method === 'GET') {
      const bankId = bankMatch[1];
      const bank = db.getBankById(bankId);
      if (!bank) return sendError(res, 404, `Blood bank not found with ID ${bankId}`);
      return sendJSON(res, 200, { success: true, data: bank });
    }

    // PUT /api/banks/:id/inventory
    const bankInvMatch = pathname.match(/^\/api\/banks\/([a-zA-Z0-9_-]+)\/inventory$/);
    if (bankInvMatch && method === 'PUT') {
      const bankId = bankInvMatch[1];
      const body = await parseBody(req);
      if (!body.group || body.units === undefined) {
        return sendError(res, 400, 'Fields "group" and "units" are required.');
      }
      const updated = db.updateBankInventory(bankId, body.group, body.units, body.component, body.user);
      if (!updated) return sendError(res, 404, `Blood bank not found with ID ${bankId}`);
      return sendJSON(res, 200, { success: true, message: 'Inventory updated successfully', data: updated });
    }

    // POST /api/banks/:id/inventory/adjust (Quick +/- unit)
    const bankAdjustMatch = pathname.match(/^\/api\/banks\/([a-zA-Z0-9_-]+)\/inventory\/adjust$/);
    if (bankAdjustMatch && method === 'POST') {
      const bankId = bankAdjustMatch[1];
      const body = await parseBody(req);
      if (!body.group || body.delta === undefined) {
        return sendError(res, 400, 'Fields "group" and "delta" (number) are required.');
      }
      const result = db.adjustBankStock(bankId, body.group, parseInt(body.delta) || 0, body.user);
      if (!result) return sendError(res, 404, `Blood bank or group not found.`);
      return sendJSON(res, 200, { success: true, message: 'Stock adjusted', data: result });
    }

    // 4. Smart Matching Algorithm API
    // GET /api/match?group=O-&maxDist=50&urgency=EMERGENCY
    if (pathname === '/api/match' && method === 'GET') {
      const group = query.group || 'O-';
      const maxDist = parseFloat(query.maxDist) || 50;
      const urgency = query.urgency || 'STANDARD';
      const matches = db.smartMatch(group, maxDist, urgency);
      return sendJSON(res, 200, {
        success: true,
        group,
        urgency,
        matchCount: matches.length,
        data: matches
      });
    }

    // 5. Blood Requests / Requisitions Endpoints
    // GET /api/requests
    if (pathname === '/api/requests' && method === 'GET') {
      const requests = db.getRequests(query);
      return sendJSON(res, 200, { success: true, count: requests.length, data: requests });
    }

    // POST /api/requests (Standard & Emergency requisition)
    if (pathname === '/api/requests' && method === 'POST') {
      const body = await parseBody(req);
      if (!body.bloodGroup) {
        return sendError(res, 400, 'Field "bloodGroup" is required.');
      }
      const newReq = db.createRequest(body, body.user);
      return sendJSON(res, 201, {
        success: true,
        message: 'Requisition dispatched successfully',
        data: newReq
      });
    }

    // GET /api/requests/:id
    const reqMatch = pathname.match(/^\/api\/requests\/([a-zA-Z0-9_-]+)$/);
    if (reqMatch && method === 'GET') {
      const reqId = reqMatch[1];
      const found = db.getRequestById(reqId);
      if (!found) return sendError(res, 404, `Requisition not found with ID ${reqId}`);
      return sendJSON(res, 200, { success: true, data: found });
    }

    // PATCH /api/requests/:id/stage (Advance, reset, or set delivery step)
    const reqStageMatch = pathname.match(/^\/api\/requests\/([a-zA-Z0-9_-]+)\/stage$/);
    if (reqStageMatch && method === 'PATCH') {
      const reqId = reqStageMatch[1];
      const body = await parseBody(req);
      const action = body.action || 'advance'; // 'advance', 'reset', 'set'
      const updated = db.updateRequestStage(reqId, action, body.stageIndex, body.user);
      if (!updated) return sendError(res, 404, `Requisition not found with ID ${reqId}`);
      return sendJSON(res, 200, {
        success: true,
        message: `Requisition stage updated (${action})`,
        data: updated
      });
    }

    // 6. Donors Endpoints
    // GET /api/donors
    if (pathname === '/api/donors' && method === 'GET') {
      const donors = db.getDonors(query);
      return sendJSON(res, 200, { success: true, count: donors.length, data: donors });
    }

    // POST /api/donors
    if (pathname === '/api/donors' && method === 'POST') {
      const body = await parseBody(req);
      if (!body.name || !body.bloodGroup) {
        return sendError(res, 400, 'Fields "name" and "bloodGroup" are required.');
      }
      const newDonor = db.createDonor(body, body.user);
      return sendJSON(res, 201, {
        success: true,
        message: 'Donor registered successfully',
        data: newDonor
      });
    }

    // 7. Hospitals Directory
    // GET /api/hospitals
    if (pathname === '/api/hospitals' && method === 'GET') {
      const hospitals = db.getHospitals();
      return sendJSON(res, 200, { success: true, count: hospitals.length, data: hospitals });
    }

    // 8. ML Inventory Predictions & Recalculation
    // GET /api/predictions
    if (pathname === '/api/predictions' && method === 'GET') {
      const predictions = db.getPredictions();
      return sendJSON(res, 200, { success: true, data: predictions });
    }

    // POST /api/predictions/recalculate
    if (pathname === '/api/predictions/recalculate' && method === 'POST') {
      const recalculated = db.recalculatePredictions();
      return sendJSON(res, 200, {
        success: true,
        message: 'Predictions recalculated based on active inventory & requisitions',
        data: recalculated
      });
    }

    // 9. Notifications
    // GET /api/notifications
    if (pathname === '/api/notifications' && method === 'GET') {
      const notifs = db.getNotifications();
      return sendJSON(res, 200, { success: true, data: notifs });
    }

    // POST /api/notifications
    if (pathname === '/api/notifications' && method === 'POST') {
      const body = await parseBody(req);
      if (!body.title || !body.message) {
        return sendError(res, 400, 'Fields "title" and "message" are required.');
      }
      const notif = db.addNotification(body.title, body.message, body.type || 'blue');
      return sendJSON(res, 201, { success: true, data: notif });
    }

    // 10. System Audit Logs
    // GET /api/logs
    if (pathname === '/api/logs' && method === 'GET') {
      const logs = db.getAuditLogs();
      return sendJSON(res, 200, { success: true, count: logs.length, data: logs });
    }

    // 11. Database Reset
    // POST /api/reset
    if (pathname === '/api/reset' && method === 'POST') {
      const freshData = db.reset();
      return sendJSON(res, 200, {
        success: true,
        message: 'Database reset to initial clean seed state',
        stats: db.getStats()
      });
    }

    // Not Found API route
    return sendError(res, 404, `API route not found: ${method} ${pathname}`);
  } catch (error) {
    console.error(`API Error on ${method} ${pathname}:`, error);
    return sendError(res, 500, 'Internal Server Error', error.message);
  }
}

// Static File Server
function serveStaticFile(req, res, pathname) {
  let reqPath = decodeURI(pathname);
  if (reqPath === '/' || reqPath === '') {
    reqPath = '/index.html';
  }

  const filePath = path.join(BASE_DIR, reqPath);

  // Security check: ensure path stays within BASE_DIR
  if (!filePath.startsWith(BASE_DIR)) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    res.end('403 Forbidden');
    return;
  }

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      // Fallback to index.html for client-side routing
      const indexPath = path.join(BASE_DIR, 'index.html');
      fs.readFile(indexPath, (readErr, content) => {
        if (readErr) {
          res.writeHead(404, { 'Content-Type': 'text/plain' });
          res.end('404 Not Found');
        } else {
          setCorsHeaders(res);
          res.writeHead(200, { 'Content-Type': 'text/html; charset=UTF-8' });
          res.end(content);
        }
      });
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    fs.readFile(filePath, (readErr, data) => {
      if (readErr) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('500 Internal Server Error');
        return;
      }

      setCorsHeaders(res);
      res.writeHead(200, {
        'Content-Type': contentType,
        'Cache-Control': 'no-cache'
      });
      res.end(data);
    });
  });
}

// HTTP Server Entrypoint
const server = http.createServer((req, res) => {
  setCorsHeaders(res);

  // Handle CORS Preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;

  // Route API vs Static files
  if (pathname.startsWith('/api/')) {
    handleApiRequest(req, res, pathname, parsedUrl.searchParams);
  } else {
    serveStaticFile(req, res, pathname);
  }
});

server.listen(PORT, () => {
  console.log(`====================================================`);
  console.log(` BloodPulse Enterprise Server & REST API Online!`);
  console.log(` Local URL: http://localhost:${PORT}`);
  console.log(` Health API: http://localhost:${PORT}/api/health`);
  console.log(` Stats API:  http://localhost:${PORT}/api/stats`);
  console.log(` Banks API:  http://localhost:${PORT}/api/banks`);
  console.log(` Requests:   http://localhost:${PORT}/api/requests`);
  console.log(` Donors:     http://localhost:${PORT}/api/donors`);
  console.log(` Persistence: database.json (ACID Safe)`);
  console.log(`====================================================`);
});

export default server;
