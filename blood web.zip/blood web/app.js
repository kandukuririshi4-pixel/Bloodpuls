/**
 * BloodPulse - Core Application Logic & State Engine
 * Connected directly to Enterprise REST API at /api/*
 * Strictly adhering to:
 * - Primary: #2563EB (Blue), #0F172A (Navy), #16A34A (Green), #F59E0B (Amber)
 * - ZERO RED COLOR.
 */

import {
  COMPATIBILITY_RULES,
  INVENTORY_STATUS_DATA,
  INITIAL_BLOOD_BANKS,
  INITIAL_REQUESTS,
  INITIAL_DONORS,
  HOSPITALS_LIST,
  ROLE_PROFILES
} from './data.js';

const API_BASE = '/api';

const api = {
  async get(endpoint) {
    try {
      const res = await fetch(`${API_BASE}${endpoint}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch (e) {
      console.warn(`API GET ${endpoint} error:`, e);
      return null;
    }
  },
  async post(endpoint, data) {
    try {
      const res = await fetch(`${API_BASE}${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch (e) {
      console.warn(`API POST ${endpoint} error:`, e);
      return null;
    }
  },
  async put(endpoint, data) {
    try {
      const res = await fetch(`${API_BASE}${endpoint}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch (e) {
      console.warn(`API PUT ${endpoint} error:`, e);
      return null;
    }
  },
  async patch(endpoint, data) {
    try {
      const res = await fetch(`${API_BASE}${endpoint}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch (e) {
      console.warn(`API PATCH ${endpoint} error:`, e);
      return null;
    }
  }
};

class BloodPulseApp {
  constructor() {
    this.state = {
      bloodBanks: this.loadFromStorage('bloodpulse_banks') || this.loadFromStorage('bloodlink_banks', INITIAL_BLOOD_BANKS),
      requests: this.loadFromStorage('bloodpulse_requests') || this.loadFromStorage('bloodlink_requests', INITIAL_REQUESTS),
      donors: this.loadFromStorage('bloodpulse_donors') || this.loadFromStorage('bloodlink_donors', INITIAL_DONORS),
      hospitals: HOSPITALS_LIST,
      currentRole: this.loadFromStorage('bloodpulse_role') || this.loadFromStorage('bloodlink_role', 'patient'),
      activeView: 'home',
      activeTrackedRequestId: null,
      selectedRequestTarget: null, // for standard request modal
      backendConnected: false,
      serverUptime: null,
      serverStats: null,
      notifications: [
        { id: 1, title: 'Emergency Dispatch Active', message: 'Courier Vikram Joshi en route with 2 units O- to Mercy Hospital.', time: '5m ago', type: 'amber' },
        { id: 2, title: 'Temperature Calibrated', message: 'Cold-Chain Unit #14 reports box temperature steady at 3.6°C.', time: '12m ago', type: 'green' },
        { id: 3, title: 'Inventory Synchronized', message: 'City Care Blood Bank refreshed morning stock counts.', time: '20m ago', type: 'blue' }
      ]
    };

    if (this.state.requests.length > 0) {
      this.state.activeTrackedRequestId = this.state.requests[0].id;
    }

    this.init();
  }

  loadFromStorage(key, fallback) {
    try {
      const saved = localStorage.getItem(key);
      return saved ? JSON.parse(saved) : fallback;
    } catch (e) {
      console.warn('LocalStorage access warning:', e);
      return fallback;
    }
  }

  saveToStorage(key, val) {
    try {
      localStorage.setItem(key, JSON.stringify(val));
    } catch (e) {
      console.warn('LocalStorage save warning:', e);
    }
  }

  async init() {
    this.setupNavigation();
    this.setupRoleSwitcher();
    this.renderAllViews();
    this.updateStatsCounters();
    this.renderActiveRoleHeader();
    this.exposeGlobalHandlers();
    await this.syncWithBackend();
  }

  async syncWithBackend() {
    const t0 = performance.now();
    try {
      const health = await api.get('/health');
      const ping = Math.round(performance.now() - t0);
      if (health && health.success) {
        this.state.backendConnected = true;
        this.state.serverUptime = health.uptimeSeconds;
        this.updateBackendIndicator(true, health, ping);

        const [banksRes, reqsRes, donorsRes, statsRes, notifsRes] = await Promise.all([
          api.get('/banks'),
          api.get('/requests'),
          api.get('/donors'),
          api.get('/stats'),
          api.get('/notifications')
        ]);

        if (banksRes && banksRes.success && Array.isArray(banksRes.data)) {
          this.state.bloodBanks = banksRes.data;
          this.saveToStorage('bloodlink_banks', this.state.bloodBanks);
        }

        if (reqsRes && reqsRes.success && Array.isArray(reqsRes.data)) {
          this.state.requests = reqsRes.data;
          this.saveToStorage('bloodlink_requests', this.state.requests);
          if (!this.state.activeTrackedRequestId && this.state.requests.length > 0) {
            this.state.activeTrackedRequestId = this.state.requests[0].id;
          }
        }

        if (donorsRes && donorsRes.success && Array.isArray(donorsRes.data)) {
          this.state.donors = donorsRes.data;
          this.saveToStorage('bloodlink_donors', this.state.donors);
        }

        if (statsRes && statsRes.success) {
          this.state.serverStats = statsRes.data;
        }

        if (notifsRes && notifsRes.success && Array.isArray(notifsRes.data)) {
          this.state.notifications = notifsRes.data;
        }

        this.renderAllViews();
        this.updateStatsCounters();
        console.log(`[BloodPulse] Connected to Node REST API (${ping}ms)`);
      } else {
        this.updateBackendIndicator(false);
      }
    } catch (err) {
      console.warn('[BloodPulse] Backend sync fallback to local mode:', err);
      this.updateBackendIndicator(false);
    }
  }

  updateBackendIndicator(online, health = null, latency = 0) {
    const pill = document.getElementById('backend-status-pill');
    const text = document.getElementById('backend-status-text');
    const modalBadge = document.getElementById('api-modal-status-badge');
    const modalUptime = document.getElementById('api-modal-uptime');
    const modalLatency = document.getElementById('api-modal-latency');

    if (online) {
      if (pill) {
        pill.classList.remove('offline');
        pill.title = `REST API Connected: http://localhost:3000 (${latency}ms)`;
      }
      if (text) text.textContent = `Backend: Online (${latency}ms)`;
      if (modalBadge) {
        modalBadge.textContent = '🟢 ONLINE';
        modalBadge.className = 'status-normal';
      }
      if (modalUptime && health) {
        const mins = Math.floor(health.uptimeSeconds / 60);
        const secs = health.uptimeSeconds % 60;
        modalUptime.textContent = `${mins}m ${secs}s (PID: Node.js)`;
      }
      if (modalLatency) modalLatency.textContent = `${latency} ms`;
    } else {
      if (pill) {
        pill.classList.add('offline');
        pill.title = 'Offline mode (LocalStorage fallback active)';
      }
      if (text) text.textContent = 'Backend: Offline (Local Mode)';
      if (modalBadge) {
        modalBadge.textContent = '🟡 OFFLINE (FALLBACK)';
        modalBadge.className = 'status-low';
      }
      if (modalLatency) modalLatency.textContent = 'N/A';
    }
  }

  // =========================================================================
  // Navigation & View Routing
  // =========================================================================
  setupNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
      item.addEventListener('click', () => {
        const page = item.getAttribute('data-page');
        this.navigateTo(page);
      });
    });
  }

  navigateTo(viewId) {
    this.state.activeView = viewId;

    // Update active class on views
    document.querySelectorAll('.page-view').forEach(view => {
      view.classList.remove('active');
    });

    const targetView = document.getElementById(`view-${viewId}`);
    if (targetView) {
      targetView.classList.add('active');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // Update nav link active state
    document.querySelectorAll('.nav-item').forEach(item => {
      if (item.getAttribute('data-page') === viewId) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });

    // Re-render context-specific views on entry
    if (viewId === 'dashboard') {
      this.renderDashboard();
    } else if (viewId === 'delivery') {
      this.renderDeliveryTrackingView();
    } else if (viewId === 'find-blood') {
      this.applyBloodFilters();
    }
  }

  // =========================================================================
  // Role Management
  // =========================================================================
  setupRoleSwitcher() {
    document.querySelectorAll('.role-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const role = e.currentTarget.getAttribute('data-role');
        this.switchRole(role);
      });
    });
  }

  switchRole(roleKey) {
    if (!ROLE_PROFILES[roleKey]) return;
    this.state.currentRole = roleKey;
    this.saveToStorage('bloodlink_role', roleKey);

    document.querySelectorAll('.role-btn').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-role') === roleKey);
    });

    this.renderActiveRoleHeader();

    const profile = ROLE_PROFILES[roleKey];
    this.showToast(`Switched Role: ${profile.title}`, `Logged in as ${profile.name}`, 'blue');

    if (this.state.activeView === 'dashboard') {
      this.renderDashboard();
    }
  }

  renderActiveRoleHeader() {
    const profile = ROLE_PROFILES[this.state.currentRole];
    const badge = document.getElementById('current-role-badge');
    const userName = document.getElementById('current-user-name');
    const authLabel = document.getElementById('nav-auth-label');

    if (badge) badge.textContent = profile.title;
    if (userName) userName.textContent = `(${profile.name} — ${profile.facility})`;
    if (authLabel) authLabel.textContent = profile.avatarText;
  }

  // =========================================================================
  // Live Stats Counter (Homepage Strip)
  // =========================================================================
  updateStatsCounters() {
    let totalBloodUnits = 0;
    this.state.bloodBanks.forEach(bank => {
      Object.values(bank.inventory).forEach(item => {
        totalBloodUnits += (item.units || 0);
      });
    });

    const activeBloodBanks = this.state.bloodBanks.length;
    const completedOrActiveDeliveries = this.state.requests.length;

    const unitsEl = document.getElementById('stat-blood-units');
    const banksEl = document.getElementById('stat-blood-banks');
    const delivEl = document.getElementById('stat-deliveries');

    // Default stats to requested 248 / 32 / 156 if calculated is lower for richer initial presentation
    if (unitsEl) unitsEl.textContent = Math.max(248, totalBloodUnits);
    if (banksEl) banksEl.textContent = Math.max(32, activeBloodBanks);
    if (delivEl) delivEl.textContent = Math.max(156, completedOrActiveDeliveries + 153);
  }

  // =========================================================================
  // Smart Blood Bank Matching Algorithm
  // Differentiating Feature 2
  // =========================================================================
  calculateSmartMatch(bloodGroup, maxDist = 50, urgency = 'STANDARD') {
    const compatibleDonors = COMPATIBILITY_RULES[bloodGroup] || [bloodGroup];
    const matches = [];

    this.state.bloodBanks.forEach(bank => {
      if (bank.distanceKm > maxDist) return;

      let directUnits = bank.inventory[bloodGroup] ? bank.inventory[bloodGroup].units : 0;
      let totalCompatibleUnits = 0;

      compatibleDonors.forEach(donorGroup => {
        if (bank.inventory[donorGroup]) {
          totalCompatibleUnits += bank.inventory[donorGroup].units;
        }
      });

      if (totalCompatibleUnits > 0 || directUnits > 0) {
        // Smart Scoring:
        // Direct compatibility weight (40%) + Stock abundance (30%) + Proximity (30%)
        const compatibilityScore = directUnits > 0 ? 100 : 75;
        const stockScore = Math.min(100, directUnits * 10);
        const distanceScore = Math.max(20, 100 - (bank.distanceKm * 8));

        let urgencyBoost = urgency === 'EMERGENCY' ? (15 / (bank.distanceKm + 1)) : 0;
        let finalMatchScore = Math.min(99, Math.round((compatibilityScore * 0.4) + (stockScore * 0.3) + (distanceScore * 0.3) + urgencyBoost));

        matches.push({
          bank,
          directUnits,
          totalCompatibleUnits,
          matchScore: finalMatchScore,
          primaryComponent: bank.inventory[bloodGroup]?.component || 'Packed RBC',
          lastRefreshed: bank.inventory[bloodGroup]?.lastRefreshed || '5 minutes ago'
        });
      }
    });

    matches.sort((a, b) => b.matchScore - a.matchScore);
    return matches;
  }

  // =========================================================================
  // RENDER: Homepage Featured Cards
  // Format: "A+ Positive — 8 Units Available / City Care Blood Bank / 2.4 km away"
  // =========================================================================
  renderHomepageFeatured() {
    const container = document.getElementById('homepage-featured-blood-cards');
    if (!container) return;

    // Showcase diverse groups: A+, O-, B+, AB+, O+
    const samplePicks = [
      { group: 'A+', bankId: 'bb-1', isRec: true },
      { group: 'O-', bankId: 'bb-1', isRec: true },
      { group: 'B+', bankId: 'bb-3', isRec: false },
      { group: 'AB+', bankId: 'bb-5', isRec: false },
      { group: 'O+', bankId: 'bb-2', isRec: false },
      { group: 'A-', bankId: 'bb-3', isRec: false }
    ];

    container.innerHTML = samplePicks.map(item => {
      const bank = this.state.bloodBanks.find(b => b.id === item.bankId) || this.state.bloodBanks[0];
      const inv = bank.inventory[item.group] || { units: 6, component: 'Packed RBC', lastRefreshed: '5 minutes ago' };

      return `
        <div class="blood-match-card ${item.isRec ? 'recommended-match' : ''}">
          ${item.isRec ? '<div class="recommended-pill">⭐ Smart Match Recommended</div>' : ''}
          <div>
            <div class="card-blood-header">
              <div class="blood-group-badge">${item.group}</div>
              <div class="card-title-group">
                <h4>${item.group} Positive — ${inv.units} Units Available</h4>
                <div class="units-available-text">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                  ${inv.component} Ready
                </div>
              </div>
            </div>

            <div class="card-bank-meta">
              <div class="bank-name-row">
                <span>${bank.name}</span>
                <span class="distance-tag">📍 ${bank.distanceKm} km away</span>
              </div>
              <div class="card-meta-row">
                <span class="last-updated-text">⏱️ Last updated: ${inv.lastRefreshed}</span>
                <span style="color: #16A34A; font-weight: 600;">Cold-Chain Verified</span>
              </div>
            </div>
          </div>

          <div class="card-action-bar">
            <button class="btn-card-request" onclick="window.initiateBloodRequest('${bank.id}', '${item.group}')">
              Request Blood
            </button>
            <button class="btn-card-call" title="Call Blood Bank" onclick="window.callBank('${bank.phone}')">
              📞
            </button>
          </div>
        </div>
      `;
    }).join('');
  }

  // =========================================================================
  // RENDER: Find Blood & Filter Search
  // =========================================================================
  applyBloodFilters() {
    const groupSelect = document.getElementById('filter-blood-group');
    const compSelect = document.getElementById('filter-component');
    const distSelect = document.getElementById('filter-max-distance');
    const compModeSelect = document.getElementById('filter-compatibility-mode');

    const selectedGroup = groupSelect ? groupSelect.value : 'ALL';
    const selectedComp = compSelect ? compSelect.value : 'ALL';
    const maxDist = distSelect ? parseFloat(distSelect.value) : 50;
    const compatMode = compModeSelect ? compModeSelect.value : 'strict';

    const grid = document.getElementById('find-blood-results-grid');
    const countEl = document.getElementById('search-results-count');
    if (!grid) return;

    let results = [];

    this.state.bloodBanks.forEach(bank => {
      if (bank.distanceKm > maxDist) return;

      Object.entries(bank.inventory).forEach(([grp, inv]) => {
        // Group filter check
        if (selectedGroup !== 'ALL') {
          if (compatMode === 'strict' && grp !== selectedGroup) return;
          if (compatMode === 'compatible') {
            const allowed = COMPATIBILITY_RULES[selectedGroup] || [selectedGroup];
            if (!allowed.includes(grp)) return;
          }
        }

        // Component filter check
        if (selectedComp !== 'ALL' && inv.component !== selectedComp) return;

        results.push({
          bank,
          group: grp,
          inv
        });
      });
    });

    if (countEl) countEl.textContent = `Showing ${results.length} verified available batches`;

    if (results.length === 0) {
      grid.innerHTML = `
        <div style="grid-column: 1/-1; background: #FFFFFF; border: 1px dashed var(--border-strong); border-radius: var(--radius-xl); padding: 3rem; text-align: center;">
          <h4 style="color: var(--dark); margin-bottom: 0.5rem;">No Blood Units Found With Current Filters</h4>
          <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1.25rem;">Try broadening your distance radius or switching to compatible donor mode.</p>
          <button class="btn-primary" onclick="document.getElementById('filter-blood-group').value='ALL'; window.applyBloodFilters();">
            Reset Filters
          </button>
        </div>
      `;
      return;
    }

    grid.innerHTML = results.map(item => `
      <div class="blood-match-card">
        <div>
          <div class="card-blood-header">
            <div class="blood-group-badge">${item.group}</div>
            <div class="card-title-group">
              <h4>${item.group} — ${item.inv.units} Units Available</h4>
              <div class="units-available-text">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
                ${item.inv.component}
              </div>
            </div>
          </div>

          <div class="card-bank-meta">
            <div class="bank-name-row">
              <span>${item.bank.name}</span>
              <span class="distance-tag">📍 ${item.bank.distanceKm} km away</span>
            </div>
            <div class="card-meta-row">
              <span class="last-updated-text">⏱️ Last updated: ${item.inv.lastRefreshed}</span>
              <span style="color: #16A34A; font-weight: 600;">Cold-Chain Verified</span>
            </div>
          </div>
        </div>

        <div class="card-action-bar">
          <button class="btn-card-request" onclick="window.initiateBloodRequest('${item.bank.id}', '${item.group}')">
            Request Blood
          </button>
          <button class="btn-card-call" title="Call Blood Bank" onclick="window.callBank('${item.bank.phone}')">
            📞
          </button>
        </div>
      </div>
    `).join('');
  }

  // =========================================================================
  // RENDER: Blood Inventory Prediction (ML Engine Differentiator 1)
  // Badges: A+ - Normal, O- - Low Stock, B+ - High Demand
  // =========================================================================
  renderInventoryPredictions() {
    const container = document.getElementById('inventory-prediction-cards');
    const dashContainer = document.getElementById('dash-prediction-cards');
    const tableBody = document.getElementById('dash-prediction-table-body');

    const htmlCards = Object.entries(INVENTORY_STATUS_DATA).map(([grp, data]) => `
      <div class="prediction-card">
        <div class="pred-blood-type">${grp}</div>
        <span class="${data.badgeType}">${data.status}</span>
        <div class="pred-trend">${data.stockTrend}</div>
      </div>
    `).join('');

    if (container) container.innerHTML = htmlCards;
    if (dashContainer) dashContainer.innerHTML = htmlCards;

    if (tableBody) {
      tableBody.innerHTML = Object.entries(INVENTORY_STATUS_DATA).map(([grp, data]) => {
        let recText = 'Maintain routine buffer';
        if (data.status === 'Low Stock') recText = 'Mobilize voluntary donor camp & alert standby donors';
        if (data.status === 'High Demand') recText = 'Prioritize for acute trauma admissions';

        return `
          <tr>
            <td><strong style="font-size: 1.1rem; color: var(--dark);">${grp}</strong></td>
            <td><span class="${data.badgeType}">${data.status}</span></td>
            <td>
              <div style="display: flex; align-items: center; gap: 0.6rem;">
                <div style="background: var(--bg); width: 80px; height: 6px; border-radius: 3px; overflow: hidden;">
                  <div style="background: var(--primary); width: ${data.demandIndex}%; height: 100%;"></div>
                </div>
                <span style="font-weight: 700; font-size: 0.85rem;">${data.demandIndex}/100</span>
              </div>
            </td>
            <td><span style="font-weight: 600; color: var(--dark);">${data.stockTrend}</span></td>
            <td><span style="color: var(--text-muted);">${data.safetyDays} days buffer</span></td>
            <td><span style="font-size: 0.84rem; color: var(--primary); font-weight: 600;">${recText}</span></td>
          </tr>
        `;
      }).join('');
    }
  }

  // =========================================================================
  // RENDER: Blood Banks Directory
  // =========================================================================
  renderBloodBanksDirectory() {
    const grid = document.getElementById('blood-banks-directory-grid');
    if (!grid) return;

    grid.innerHTML = this.state.bloodBanks.map(bank => {
      let totalUnits = 0;
      Object.values(bank.inventory).forEach(inv => totalUnits += inv.units);

      return `
        <div class="blood-match-card">
          <div>
            <div style="display: flex; align-items: flex-start; justify-content: space-between; margin-bottom: 0.75rem;">
              <span class="badge-status-pill">${bank.badge}</span>
              <span style="font-weight: 700; color: #16A34A; font-size: 0.82rem;">⭐ ${bank.rating} / 5.0</span>
            </div>

            <h3 style="font-size: 1.25rem; color: var(--dark); margin-bottom: 0.25rem;">${bank.name}</h3>
            <p style="font-size: 0.84rem; color: var(--text-muted); margin-bottom: 1rem;">📍 ${bank.address}</p>

            <div class="card-bank-meta">
              <div class="bank-name-row">
                <span>Active Blood Units</span>
                <span style="color: #16A34A; font-weight: 800;">${totalUnits} Units in Cryo</span>
              </div>
              <div class="card-meta-row" style="margin-top: 0.4rem;">
                <span>Transit Distance:</span>
                <span class="distance-tag">${bank.distanceKm} km</span>
              </div>
              <div class="card-meta-row" style="margin-top: 0.4rem;">
                <span>Emergency Desk:</span>
                <span style="color: var(--dark); font-weight: 600;">${bank.openHours}</span>
              </div>
            </div>
          </div>

          <div class="card-action-bar">
            <button class="btn-card-request" onclick="window.openRequisitionForBank('${bank.id}')">
              Requisition Blood
            </button>
            <button class="btn-card-call" onclick="window.callBank('${bank.phone}')">
              📞 ${bank.phone}
            </button>
          </div>
        </div>
      `;
    }).join('');
  }

  // =========================================================================
  // RENDER: Hospitals Directory
  // =========================================================================
  renderHospitalsDirectory() {
    const grid = document.getElementById('hospitals-directory-grid');
    if (!grid) return;

    grid.innerHTML = this.state.hospitals.map(hosp => `
      <div class="blood-match-card">
        <div>
          <span class="badge-status-pill" style="margin-bottom: 0.75rem; display: inline-block;">${hosp.type}</span>
          <h3 style="font-size: 1.25rem; color: var(--dark); margin-bottom: 0.25rem;">${hosp.name}</h3>
          <p style="font-size: 0.84rem; color: var(--text-muted); margin-bottom: 1rem;">📍 ${hosp.address}</p>

          <div class="card-bank-meta">
            <div class="bank-name-row">
              <span>Emergency Liaison</span>
              <span style="color: var(--primary); font-weight: 700;">${hosp.emergencyDesk}</span>
            </div>
            <div class="card-meta-row" style="margin-top: 0.4rem;">
              <span>Daily Unit Need:</span>
              <span style="font-weight: 700; color: var(--dark);">${hosp.dailyUnitsNeeded} Units</span>
            </div>
            <div class="card-meta-row" style="margin-top: 0.4rem;">
              <span>Status:</span>
              <span style="color: #16A34A; font-weight: 600;">${hosp.liveStatus}</span>
            </div>
          </div>
        </div>

        <div class="card-action-bar">
          <button class="btn-card-request" onclick="window.openEmergencyModal()">
            ⚡ Emergency Requisition
          </button>
          <button class="btn-card-call" onclick="window.callBank('${hosp.contact}')">
            📞 Direct Line
          </button>
        </div>
      </div>
    `).join('');
  }

  // =========================================================================
  // DELIVERY TRACKING SYSTEM: 6-Step Visual Progress Tracker
  // REQUESTED -> VERIFICATION -> APPROVED -> BLOOD PACKED -> OUT FOR DELIVERY -> DELIVERED
  // =========================================================================
  renderDeliveryTrackingView() {
    const selector = document.getElementById('delivery-request-selector');
    if (selector) {
      selector.innerHTML = this.state.requests.map(req => `
        <option value="${req.id}" ${req.id === this.state.activeTrackedRequestId ? 'selected' : ''}>
          ${req.id} — ${req.bloodGroup} (${req.units}u) - ${req.patientName}
        </option>
      `).join('');
    }

    const currentReq = this.state.requests.find(r => r.id === this.state.activeTrackedRequestId) || this.state.requests[0];
    if (!currentReq) return;

    // Render Header Details
    const headerEl = document.getElementById('tracker-header-content');
    if (headerEl) {
      headerEl.innerHTML = `
        <div class="tracker-headline">
          <h2>
            <span>Live Delivery Dispatch</span>
            <span class="request-id-tag">${currentReq.id}</span>
          </h2>
          <div class="tracker-subline">
            Destination: <strong>${currentReq.hospitalName}</strong> &nbsp;|&nbsp; 
            Patient: <strong>${currentReq.patientName}</strong> &nbsp;|&nbsp; 
            Source Bank: <strong>${currentReq.bloodBankName}</strong>
          </div>
        </div>

        <div class="tracker-header-badges">
          <span class="${currentReq.urgency === 'EMERGENCY' ? 'badge-urgency-emergency' : 'badge-status-pill'}">
            ${currentReq.urgency === 'EMERGENCY' ? '⚡ EMERGENCY PROTOCOL' : 'STANDARD PRIORITY'}
          </span>
          <span class="badge-status-pill" style="font-weight: 800;">
            ${currentReq.bloodGroup} — ${currentReq.units} Unit (${currentReq.component})
          </span>
        </div>
      `;
    }

    // Render 6-Step Progress Stepper
    // Steps: 0: REQUESTED, 1: VERIFICATION, 2: APPROVED, 3: BLOOD PACKED, 4: OUT FOR DELIVERY, 5: DELIVERED
    const stages = ['REQUESTED', 'VERIFICATION', 'APPROVED', 'BLOOD PACKED', 'OUT FOR DELIVERY', 'DELIVERED'];
    const activeIndex = currentReq.stageIndex;

    const fillBar = document.getElementById('stepper-fill-bar');
    if (fillBar) {
      const percentage = (activeIndex / 5) * 100;
      fillBar.style.width = `${percentage}%`;
    }

    const stepNodes = document.querySelectorAll('#delivery-stepper-container .step-node');
    stepNodes.forEach((node, idx) => {
      node.classList.remove('completed', 'active');
      const circle = node.querySelector('.step-circle');
      const timeEl = node.querySelector('.step-time');

      if (idx < activeIndex) {
        node.classList.add('completed');
        if (circle) circle.textContent = '✓';
        if (timeEl && currentReq.timeline[idx]) timeEl.textContent = currentReq.timeline[idx].time;
      } else if (idx === activeIndex) {
        node.classList.add('active');
        if (circle) circle.textContent = idx === 4 ? '🚚' : (idx + 1);
        if (timeEl && currentReq.timeline[idx]) timeEl.textContent = currentReq.timeline[idx].time;
      } else {
        if (circle) circle.textContent = (idx + 1);
        if (timeEl) timeEl.textContent = 'Pending';
      }
    });

    // Update Telemetry HUD
    const etaEl = document.getElementById('telemetry-eta');
    const distEl = document.getElementById('telemetry-dist');
    const tempEl = document.getElementById('telemetry-temp');
    const otpEl = document.getElementById('telemetry-otp');
    const boxTempReadout = document.getElementById('box-temp-readout');
    const courierNameDisplay = document.getElementById('courier-name-display');
    const courierVehicleDisplay = document.getElementById('courier-vehicle-display');
    const courierAvatar = document.getElementById('courier-avatar-bubble');

    if (etaEl) etaEl.textContent = activeIndex === 5 ? 'Arrived & Handed Over' : `${currentReq.etaMinutes} Minutes`;
    if (distEl) distEl.textContent = activeIndex === 5 ? '0.0 km (Delivered)' : `${currentReq.distanceRemainingKm} km`;
    if (tempEl) tempEl.textContent = currentReq.boxTemperature;
    if (boxTempReadout) boxTempReadout.textContent = currentReq.boxTemperature.split(' ')[0];
    if (otpEl) otpEl.textContent = currentReq.verificationCode;
    if (courierNameDisplay) courierNameDisplay.textContent = currentReq.courierName;
    if (courierVehicleDisplay) courierVehicleDisplay.textContent = currentReq.courierVehicle;
    if (courierAvatar) courierAvatar.textContent = currentReq.courierName.split(' ')[0][0] + currentReq.courierName.split(' ')[1][0];

    // Map marker position animation adjustment based on stage
    const courierMarker = document.getElementById('animated-courier-marker');
    if (courierMarker) {
      if (activeIndex <= 1) {
        courierMarker.setAttribute('transform', 'translate(60, 240)');
      } else if (activeIndex === 2 || activeIndex === 3) {
        courierMarker.setAttribute('transform', 'translate(140, 240)');
      } else if (activeIndex === 4) {
        courierMarker.setAttribute('transform', 'translate(360, 150)');
      } else if (activeIndex >= 5) {
        courierMarker.setAttribute('transform', 'translate(530, 60)');
      }
    }
  }

  async advanceDeliveryStep() {
    const currentReq = this.state.requests.find(r => r.id === this.state.activeTrackedRequestId);
    if (!currentReq) return;

    if (currentReq.stageIndex < 5) {
      const res = await api.patch(`/requests/${currentReq.id}/stage`, {
        action: 'advance',
        user: ROLE_PROFILES[this.state.currentRole]?.name || 'Delivery Fleet'
      });

      if (res && res.success && res.data) {
        Object.assign(currentReq, res.data);
      } else {
        currentReq.stageIndex += 1;
        const stages = ['REQUESTED', 'VERIFICATION', 'APPROVED', 'BLOOD PACKED', 'OUT FOR DELIVERY', 'DELIVERED'];
        currentReq.status = stages[currentReq.stageIndex];
        if (currentReq.stageIndex === 5) {
          currentReq.etaMinutes = 0;
          currentReq.distanceRemainingKm = 0;
        } else {
          currentReq.etaMinutes = Math.max(2, currentReq.etaMinutes - 6);
          currentReq.distanceRemainingKm = (currentReq.distanceRemainingKm * 0.6).toFixed(1);
        }
      }

      if (currentReq.stageIndex === 5) {
        this.showToast('Delivery Fulfilled!', `Requisition ${currentReq.id} delivered safely to ${currentReq.hospitalName}`, 'green');
      } else {
        this.showToast('Transit Update', `Status advanced to: ${currentReq.status}`, 'blue');
      }

      this.saveToStorage('bloodlink_requests', this.state.requests);
      this.renderDeliveryTrackingView();
      this.renderDashboard();
      this.updateStatsCounters();
    } else {
      this.showToast('Already Delivered', 'This requisition is already marked as DELIVERED.', 'blue');
    }
  }

  async resetDeliverySimulation() {
    const currentReq = this.state.requests.find(r => r.id === this.state.activeTrackedRequestId);
    if (!currentReq) return;

    const res = await api.patch(`/requests/${currentReq.id}/stage`, {
      action: 'reset',
      user: ROLE_PROFILES[this.state.currentRole]?.name || 'Delivery Fleet'
    });

    if (res && res.success && res.data) {
      Object.assign(currentReq, res.data);
    } else {
      currentReq.stageIndex = 0;
      currentReq.status = 'REQUESTED';
      currentReq.etaMinutes = 28;
      currentReq.distanceRemainingKm = 4.2;
    }

    this.saveToStorage('bloodlink_requests', this.state.requests);
    this.renderDeliveryTrackingView();
    this.renderDashboard();
    this.showToast('Simulation Reset', 'Tracker set back to Step 1: REQUESTED', 'blue');
  }

  // =========================================================================
  // RENDER: Unified Role-Based Dashboard
  // =========================================================================
  renderDashboard() {
    const profile = ROLE_PROFILES[this.state.currentRole];
    const nameEl = document.getElementById('dash-user-name');
    const avatarEl = document.getElementById('dash-user-avatar');
    const roleEl = document.getElementById('dash-user-role-label');
    const facilityEl = document.getElementById('dash-user-facility');

    if (nameEl) nameEl.textContent = profile.name;
    if (avatarEl) avatarEl.textContent = profile.avatarText;
    if (roleEl) roleEl.textContent = profile.roleLabel;
    if (facilityEl) facilityEl.textContent = profile.facility;

    this.renderDashboardRequestsTable();
    this.renderDashboardInventoryTable();
    this.renderDashboardDeliveriesTable();
    this.renderInventoryPredictions();
    this.renderDashboardNotifications();
  }

  switchDashTab(tabKey) {
    document.querySelectorAll('.dash-tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-tab') === tabKey);
    });

    document.querySelectorAll('.dash-tab-pane').forEach(pane => {
      pane.style.display = pane.id === `dash-pane-${tabKey}` ? 'block' : 'none';
    });
  }

  renderDashboardRequestsTable() {
    const tbody = document.getElementById('dash-requests-table-body');
    if (!tbody) return;

    tbody.innerHTML = this.state.requests.map(req => `
      <tr>
        <td><strong style="font-family: monospace; color: var(--primary);">${req.id}</strong></td>
        <td>
          <div style="font-weight: 700; color: var(--dark);">${req.patientName}</div>
          <div style="font-size: 0.8rem; color: var(--text-muted);">${req.hospitalName}</div>
        </td>
        <td>
          <span style="font-weight: 800; color: var(--dark);">${req.bloodGroup}</span>
          <span style="font-size: 0.82rem; color: var(--text-muted);">(${req.units} Units, ${req.component})</span>
        </td>
        <td>${req.bloodBankName}</td>
        <td>
          <span class="${req.urgency === 'EMERGENCY' ? 'status-low' : 'status-normal'}">
            ${req.urgency}
          </span>
        </td>
        <td>
          <span class="badge-status-pill" style="font-size: 0.78rem;">${req.status}</span>
        </td>
        <td>
          <button class="btn-secondary" style="padding: 0.35rem 0.75rem; font-size: 0.8rem;" onclick="window.trackThisRequest('${req.id}')">
            Track Live →
          </button>
        </td>
      </tr>
    `).join('');
  }

  renderDashboardInventoryTable() {
    const tbody = document.getElementById('dash-inventory-table-body');
    if (!tbody) return;

    let rows = [];
    this.state.bloodBanks.forEach(bank => {
      Object.entries(bank.inventory).forEach(([grp, inv]) => {
        let statusBadge = 'status-normal';
        let statusText = 'Adequate';
        if (inv.units <= 3) {
          statusBadge = 'status-low';
          statusText = 'Low Stock';
        }

        rows.push(`
          <tr>
            <td><strong style="color: var(--dark);">${bank.name}</strong></td>
            <td><span class="blood-group-badge" style="width: 32px; height: 32px; font-size: 0.85rem; display: inline-flex;">${grp}</span></td>
            <td>${inv.component}</td>
            <td><strong style="font-size: 1.05rem; color: var(--dark);">${inv.units}</strong> Units</td>
            <td><span class="${statusBadge}">${statusText}</span></td>
            <td><span style="font-size: 0.8rem; color: var(--text-muted);">${inv.lastRefreshed}</span></td>
            <td>
              <button class="btn-secondary" style="padding: 0.25rem 0.55rem; font-size: 0.78rem;" onclick="window.quickAdjustStock('${bank.id}', '${grp}', 1)">
                +1
              </button>
              <button class="btn-secondary" style="padding: 0.25rem 0.55rem; font-size: 0.78rem;" onclick="window.quickAdjustStock('${bank.id}', '${grp}', -1)">
                -1
              </button>
            </td>
          </tr>
        `);
      });
    });

    tbody.innerHTML = rows.join('');
  }

  renderDashboardDeliveriesTable() {
    const tbody = document.getElementById('dash-deliveries-table-body');
    if (!tbody) return;

    tbody.innerHTML = this.state.requests.map(req => `
      <tr>
        <td><strong style="font-family: monospace; color: var(--dark);">${req.id}</strong></td>
        <td>
          <div style="font-weight: 600;">${req.hospitalName}</div>
          <div style="font-size: 0.8rem; color: var(--text-muted);">${req.bloodGroup} (${req.units} units)</div>
        </td>
        <td>
          <div style="font-weight: 600;">${req.courierName}</div>
          <div style="font-size: 0.8rem; color: var(--text-muted);">${req.courierVehicle}</div>
        </td>
        <td>
          <span style="color: #16A34A; font-weight: 700;">${req.boxTemperature}</span>
        </td>
        <td>
          <span class="badge-status-pill">${req.status}</span>
        </td>
        <td>${req.stageIndex === 5 ? 'Delivered' : req.etaMinutes + ' mins'}</td>
        <td>
          <button class="btn-primary" style="padding: 0.35rem 0.75rem; font-size: 0.8rem;" onclick="window.trackThisRequest('${req.id}')">
            View GPS
          </button>
        </td>
      </tr>
    `).join('');
  }

  renderDashboardNotifications() {
    const list = document.getElementById('dash-notifications-list');
    if (!list) return;

    list.innerHTML = this.state.notifications.map(item => `
      <div style="display: flex; align-items: flex-start; gap: 0.85rem; padding: 0.85rem 0; border-bottom: 1px solid var(--border);">
        <div style="font-size: 1.25rem;">
          ${item.type === 'amber' ? '⚡' : item.type === 'green' ? '✓' : 'ℹ️'}
        </div>
        <div style="flex: 1;">
          <div style="display: flex; align-items: center; justify-content: space-between;">
            <h5 style="font-size: 0.95rem; color: var(--dark);">${item.title}</h5>
            <span style="font-size: 0.75rem; color: var(--text-muted);">${item.time}</span>
          </div>
          <p style="font-size: 0.85rem; color: var(--text-muted); margin: 0.2rem 0 0;">${item.message}</p>
        </div>
      </div>
    `).join('');
  }

  // =========================================================================
  // RENDER: Donors View & Mini List
  // =========================================================================
  renderDonorsView() {
    const container = document.getElementById('donors-list-mini');
    if (!container) return;

    container.innerHTML = this.state.donors.map(donor => `
      <div style="display: flex; align-items: center; justify-content: space-between; background: var(--bg); padding: 0.75rem 1rem; border-radius: var(--radius-md); border: 1px solid var(--border);">
        <div style="display: flex; align-items: center; gap: 0.75rem;">
          <div class="blood-group-badge" style="width: 38px; height: 38px; font-size: 0.95rem;">${donor.bloodGroup}</div>
          <div>
            <h5 style="font-size: 0.92rem; color: var(--dark); margin: 0;">${donor.name}</h5>
            <span style="font-size: 0.78rem; color: var(--text-muted);">${donor.city} • ${donor.totalDonations} Donations</span>
          </div>
        </div>
        <span class="status-normal" style="font-size: 0.75rem;">${donor.eligibilityStatus}</span>
      </div>
    `).join('');
  }

  // =========================================================================
  // Modals & Action Handlers
  // =========================================================================
  openEmergencyModal() {
    document.getElementById('modal-emergency').classList.add('active');
  }

  openLoginModal() {
    document.getElementById('modal-login').classList.add('active');
  }

  openNewRequestModal() {
    this.initiateBloodRequest('bb-1', 'A+');
  }

  openUpdateStockModal() {
    document.getElementById('modal-stock').classList.add('active');
  }

  closeModals() {
    document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('active'));
  }

  async handleEmergencyFormSubmit(e) {
    e.preventDefault();
    const patientName = document.getElementById('em-patient-name').value;
    const bloodGroup = document.getElementById('em-blood-group').value;
    const units = parseInt(document.getElementById('em-units').value) || 2;
    const component = document.getElementById('em-component').value;
    const hospital = document.getElementById('em-hospital').value;
    const reason = document.getElementById('em-reason').value;

    const payload = {
      patientName,
      bloodGroup,
      units,
      component,
      hospitalName: hospital,
      reason,
      urgency: 'EMERGENCY',
      user: ROLE_PROFILES[this.state.currentRole]?.name || 'Dr. Sarah Jenkins'
    };

    let newReq = null;
    const res = await api.post('/requests', payload);

    if (res && res.success && res.data) {
      newReq = res.data;
      this.state.requests.unshift(newReq);
    } else {
      // Offline fallback
      const matches = this.calculateSmartMatch(bloodGroup, 50, 'EMERGENCY');
      const assignedBank = matches.length > 0 ? matches[0].bank : this.state.bloodBanks[0];

      newReq = {
        id: `REQ-${Math.floor(1000 + Math.random() * 9000)}`,
        patientName,
        hospitalName: hospital,
        bloodGroup,
        units,
        component,
        urgency: 'EMERGENCY',
        reason,
        bloodBankId: assignedBank.id,
        bloodBankName: assignedBank.name,
        requestedTime: 'Just now',
        stageIndex: 1,
        status: 'VERIFICATION',
        courierName: 'Rahul Verma (Express Rapid Fleet #02)',
        courierPhone: '+1 (555) 777-8899',
        courierVehicle: 'Emergency Priority EV Van #B-101',
        boxTemperature: '3.4°C (Pre-cooled transit container)',
        etaMinutes: 14,
        distanceRemainingKm: assignedBank.distanceKm,
        verificationCode: `EM-${Math.floor(1000 + Math.random() * 9000)}`,
        timeline: [
          { step: 'REQUESTED', time: 'Just now', done: true, note: 'Fast-track emergency protocol logged' },
          { step: 'VERIFICATION', time: 'In progress', done: true, note: 'Cross-match serology running at ' + assignedBank.name },
          { step: 'APPROVED', time: 'Pending', done: false, note: 'Express clearance pending' },
          { step: 'BLOOD PACKED', time: 'Pending', done: false, note: 'Cold-chain sealing' },
          { step: 'OUT FOR DELIVERY', time: 'Pending', done: false, note: 'Express dispatch' },
          { step: 'DELIVERED', time: 'Pending', done: false, note: 'Bedside handover' }
        ]
      };
      this.state.requests.unshift(newReq);
    }

    this.state.activeTrackedRequestId = newReq.id;
    this.saveToStorage('bloodlink_requests', this.state.requests);

    this.closeModals();
    this.showToast('🚨 Emergency Request Dispatched!', `Allocated to ${newReq.bloodBankName} (${newReq.distanceRemainingKm} km away)`, 'amber');
    this.renderDeliveryTrackingView();
    this.renderDashboard();
    this.updateStatsCounters();
    this.navigateTo('delivery');
  }

  initiateBloodRequest(bankId, bloodGroup) {
    const bank = this.state.bloodBanks.find(b => b.id === bankId) || this.state.bloodBanks[0];
    this.state.selectedRequestTarget = { bank, bloodGroup };

    const bankDetailsEl = document.getElementById('modal-request-bank-details');
    const stdGroupEl = document.getElementById('std-blood-group');
    const titleEl = document.getElementById('modal-request-title');

    if (bankDetailsEl) {
      bankDetailsEl.innerHTML = `
        <div style="display: flex; align-items: center; justify-content: space-between;">
          <h4 style="color: var(--dark); font-size: 1.05rem;">${bank.name}</h4>
          <span style="color: var(--primary); font-weight: 700;">📍 ${bank.distanceKm} km away</span>
        </div>
        <p style="font-size: 0.82rem; color: var(--text-muted); margin-top: 0.2rem;">${bank.address}</p>
      `;
    }

    if (stdGroupEl) stdGroupEl.value = bloodGroup;
    if (titleEl) titleEl.textContent = `Request ${bloodGroup} Units`;

    document.getElementById('modal-request').classList.add('active');
  }

  async handleStandardRequestSubmit(e) {
    e.preventDefault();
    const patientName = document.getElementById('std-patient-name').value;
    const bloodGroup = document.getElementById('std-blood-group').value;
    const units = parseInt(document.getElementById('std-units').value) || 1;
    const priority = document.getElementById('std-priority').value;
    const hospital = document.getElementById('std-hospital').value;
    const doctor = document.getElementById('std-doctor').value;

    const targetBank = this.state.selectedRequestTarget?.bank || this.state.bloodBanks[0];

    const payload = {
      patientName,
      bloodGroup,
      units,
      component: 'Packed RBC',
      urgency: priority,
      hospitalName: hospital,
      reason: `Requisition by ${doctor}`,
      doctor,
      bloodBankId: targetBank.id,
      user: ROLE_PROFILES[this.state.currentRole]?.name || doctor
    };

    let newReq = null;
    const res = await api.post('/requests', payload);

    if (res && res.success && res.data) {
      newReq = res.data;
      this.state.requests.unshift(newReq);
    } else {
      newReq = {
        id: `REQ-${Math.floor(1000 + Math.random() * 9000)}`,
        patientName,
        hospitalName: hospital,
        bloodGroup,
        units,
        component: 'Packed RBC',
        urgency: priority,
        reason: `Requisition by ${doctor}`,
        bloodBankId: targetBank.id,
        bloodBankName: targetBank.name,
        requestedTime: 'Just now',
        stageIndex: 0,
        status: 'REQUESTED',
        courierName: 'Arjun Das (Medical Transit Fleet #09)',
        courierPhone: '+1 (555) 443-8899',
        courierVehicle: 'Insulated Courier Transit Van',
        boxTemperature: '3.8°C (Optimal Safe 2-6°C)',
        etaMinutes: 26,
        distanceRemainingKm: targetBank.distanceKm,
        verificationCode: `BL-${Math.floor(1000 + Math.random() * 9000)}`,
        timeline: [
          { step: 'REQUESTED', time: 'Just now', done: true, note: `Requisition created by ${doctor}` },
          { step: 'VERIFICATION', time: 'Pending', done: false, note: 'Awaiting lab validation' },
          { step: 'APPROVED', time: 'Pending', done: false, note: 'Blood bank sign-off' },
          { step: 'BLOOD PACKED', time: 'Pending', done: false, note: 'Cryo-packing' },
          { step: 'OUT FOR DELIVERY', time: 'Pending', done: false, note: 'Courier departure' },
          { step: 'DELIVERED', time: 'Pending', done: false, note: 'Ward receipt' }
        ]
      };
      this.state.requests.unshift(newReq);
    }

    this.state.activeTrackedRequestId = newReq.id;
    this.saveToStorage('bloodlink_requests', this.state.requests);

    this.closeModals();
    this.showToast('Requisition Submitted!', `Order sent to ${targetBank.name}`, 'blue');
    this.renderDeliveryTrackingView();
    this.renderDashboard();
    this.updateStatsCounters();
    this.navigateTo('delivery');
  }

  async handleStockUpdateSubmit(e) {
    e.preventDefault();
    const bankId = document.getElementById('stock-bank-select').value;
    const bloodGroup = document.getElementById('stock-blood-group').value;
    const component = document.getElementById('stock-component').value;
    const units = parseInt(document.getElementById('stock-units').value) || 0;

    const res = await api.put(`/banks/${bankId}/inventory`, {
      group: bloodGroup,
      units,
      component,
      user: ROLE_PROFILES[this.state.currentRole]?.name || 'Marcus Vance'
    });

    const bank = this.state.bloodBanks.find(b => b.id === bankId);
    if (res && res.success && res.data) {
      if (bank) Object.assign(bank, res.data);
    } else if (bank) {
      bank.inventory[bloodGroup] = {
        units,
        component,
        lastRefreshed: 'Just now'
      };
    }

    this.saveToStorage('bloodlink_banks', this.state.bloodBanks);
    this.closeModals();
    this.showToast('Stock Updated', `${bank?.name || 'Bank'} now has ${units} units of ${bloodGroup}`, 'green');
    this.renderAllViews();
  }

  async quickAdjustStock(bankId, grp, delta) {
    const res = await api.post(`/banks/${bankId}/inventory/adjust`, {
      group: grp,
      delta,
      user: ROLE_PROFILES[this.state.currentRole]?.name || 'Marcus Vance'
    });

    const bank = this.state.bloodBanks.find(b => b.id === bankId);
    if (res && res.success && res.data) {
      if (bank) Object.assign(bank, res.data.bank);
    } else if (bank && bank.inventory[grp]) {
      bank.inventory[grp].units = Math.max(0, bank.inventory[grp].units + delta);
      bank.inventory[grp].lastRefreshed = 'Just now';
    }

    this.saveToStorage('bloodlink_banks', this.state.bloodBanks);
    this.renderAllViews();
    this.showToast('Stock Adjusted', `${bank?.name || 'Bank'} ${grp} adjusted by ${delta > 0 ? '+1' : '-1'}`, 'blue');
  }

  async handleDonorSubmit(e) {
    e.preventDefault();
    const name = document.getElementById('donor-input-name').value;
    const bloodGroup = document.getElementById('donor-input-blood').value;
    const age = document.getElementById('donor-input-age').value;
    const phone = document.getElementById('donor-input-phone').value;
    const city = document.getElementById('donor-input-city').value;

    const payload = {
      name,
      bloodGroup,
      age: parseInt(age) || 25,
      phone,
      city,
      user: name
    };

    let newDonor = null;
    const res = await api.post('/donors', payload);

    if (res && res.success && res.data) {
      newDonor = res.data;
    } else {
      newDonor = {
        id: `DON-${Math.floor(100 + Math.random() * 900)}`,
        name,
        bloodGroup,
        age: parseInt(age),
        gender: 'Volunteer',
        lastDonationDate: 'First Registration',
        totalDonations: 0,
        eligibilityStatus: 'Eligible Today',
        city,
        phone
      };
    }

    this.state.donors.unshift(newDonor);
    this.saveToStorage('bloodlink_donors', this.state.donors);

    // Update preview card
    const prevName = document.getElementById('preview-name');
    const prevBadge = document.getElementById('preview-badge-group');
    if (prevName) prevName.textContent = name;
    if (prevBadge) prevBadge.textContent = bloodGroup;

    this.renderDonorsView();
    this.showToast('Donor Registered!', `Digital Life Pass generated for ${name}`, 'green');
  }

  showToast(title, message, type = 'blue') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
      <div class="toast-icon">${type === 'amber' ? '⚡' : type === 'green' ? '✓' : 'ℹ️'}</div>
      <div class="toast-content">
        <h5>${title}</h5>
        <p>${message}</p>
      </div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 4500);
  }

  renderAllViews() {
    this.renderHomepageFeatured();
    this.renderInventoryPredictions();
    this.applyBloodFilters();
    this.renderBloodBanksDirectory();
    this.renderHospitalsDirectory();
    this.renderDeliveryTrackingView();
    this.renderDonorsView();
    this.updateStatsCounters();
  }

  // =========================================================================
  // Expose Global Handlers for HTML Inline onclick
  // =========================================================================
  exposeGlobalHandlers() {
    window.navigateTo = (viewId) => this.navigateTo(viewId);
    window.switchRole = (roleKey) => this.switchRole(roleKey);
    window.openEmergencyModal = () => this.openEmergencyModal();
    window.openLoginModal = () => this.openLoginModal();
    window.openNewRequestModal = () => this.openNewRequestModal();
    window.openUpdateStockModal = () => this.openUpdateStockModal();
    window.closeModals = () => this.closeModals();
    window.applyBloodFilters = () => this.applyBloodFilters();
    window.switchTrackedDelivery = (id) => {
      this.state.activeTrackedRequestId = id;
      this.renderDeliveryTrackingView();
    };
    window.trackThisRequest = (id) => {
      this.state.activeTrackedRequestId = id;
      this.navigateTo('delivery');
    };
    window.advanceDeliveryStep = () => this.advanceDeliveryStep();
    window.resetDeliverySimulation = () => this.resetDeliverySimulation();
    window.switchDashTab = (tab) => this.switchDashTab(tab);
    window.initiateBloodRequest = (bankId, bloodGroup) => this.initiateBloodRequest(bankId, bloodGroup);
    window.openRequisitionForBank = (bankId) => this.initiateBloodRequest(bankId, 'A+');
    window.callBank = (phone) => {
      this.showToast('Calling Blood Bank', `Dialing direct desk: ${phone}`, 'blue');
    };
    window.callCourier = () => {
      const currentReq = this.state.requests.find(r => r.id === this.state.activeTrackedRequestId);
      this.showToast('Calling Courier', `Connecting to ${currentReq?.courierName || 'Transit Courier'}...`, 'blue');
    };
    window.verifyRecipientPin = () => {
      const currentReq = this.state.requests.find(r => r.id === this.state.activeTrackedRequestId);
      this.showToast('OTP Verified', `Code ${currentReq?.verificationCode || 'BL-9824'} validated! Blood transferred.`, 'green');
    };
    window.quickAdjustStock = (bankId, grp, delta) => this.quickAdjustStock(bankId, grp, delta);
    window.handleDonorSubmit = (e) => this.handleDonorSubmit(e);
    window.handleEmergencyFormSubmit = (e) => this.handleEmergencyFormSubmit(e);
    window.handleStandardRequestSubmit = (e) => this.handleStandardRequestSubmit(e);
    window.handleStockUpdateSubmit = (e) => this.handleStockUpdateSubmit(e);
    window.handleHeroSearch = () => {
      const grp = document.getElementById('hero-blood-group-select').value;
      if (grp) {
        const filterSelect = document.getElementById('filter-blood-group');
        if (filterSelect) filterSelect.value = grp;
      }
      this.navigateTo('find-blood');
    };
    window.refreshDashboardData = async () => {
      await this.syncWithBackend();
      this.showToast('Refreshed', 'Telemetry and records synchronized with backend API.', 'blue');
    };
    window.openBackendApiModal = () => {
      document.getElementById('modal-backend-api')?.classList.add('active');
    };
    window.resetBackendDatabase = async () => {
      if (!confirm('Are you sure you want to reset the database to default clean seeds?')) return;
      const res = await api.post('/reset', {});
      if (res && res.success) {
        this.showToast('Database Reset', 'Storage restored to default seed records.', 'amber');
        await this.syncWithBackend();
        this.closeModals();
      } else {
        this.showToast('Reset Failed', 'Could not reset backend database.', 'blue');
      }
    };
    window.triggerRecalculatePredictions = async () => {
      const res = await api.post('/predictions/recalculate', {});
      if (res && res.success) {
        this.showToast('ML Predictions Recalculated', 'Blood reserves and demand curves refreshed.', 'green');
        await this.syncWithBackend();
      }
    };
    window.toggleNotificationDrawer = () => {
      this.showToast('Notifications Active', 'All recent activity logged in Dashboard notifications tab.', 'blue');
    };
    window.toggleMobileMenu = () => {
      const drawer = document.getElementById('mobile-nav-drawer');
      if (drawer) drawer.classList.toggle('open');
    };
    window.closeMobileMenu = () => {
      const drawer = document.getElementById('mobile-nav-drawer');
      if (drawer) drawer.classList.remove('open');
    };
  }
}

// Instantiate on DOM Ready
document.addEventListener('DOMContentLoaded', () => {
  window.BloodPulse = new BloodPulseApp();
  window.BloodLink = window.BloodPulse; // backward compatibility
});
