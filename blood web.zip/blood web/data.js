/**
 * BloodPulse - Realistic Initial Mock Database & Compatibility Matrix
 * Strictly adheres to the #2563EB (Blue), #0F172A (Navy), #16A34A (Green), #F59E0B (Amber) palette.
 * ZERO RED COLOR.
 */

// Blood compatibility matrix (Recipient -> Compatible Donors)
export const COMPATIBILITY_RULES = {
  'A+': ['A+', 'A-', 'O+', 'O-'],
  'A-': ['A-', 'O-'],
  'B+': ['B+', 'B-', 'O+', 'O-'],
  'B-': ['B-', 'O-'],
  'AB+': ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'], // Universal Recipient
  'AB-': ['AB-', 'A-', 'B-', 'O-'],
  'O+': ['O+', 'O-'],
  'O-': ['O-'] // Universal Donor
};

// Blood inventory status predictions based on simulated consumption & demand
export const INVENTORY_STATUS_DATA = {
  'A+': { status: 'Normal', badgeType: 'status-normal', demandIndex: 72, stockTrend: '+4% this week', safetyDays: 8 },
  'A-': { status: 'Low Stock', badgeType: 'status-low', demandIndex: 88, stockTrend: '-12% this week', safetyDays: 2 },
  'B+': { status: 'High Demand', badgeType: 'status-high', demandIndex: 94, stockTrend: '+18% surge today', safetyDays: 4 },
  'B-': { status: 'Normal', badgeType: 'status-normal', demandIndex: 64, stockTrend: '+2% this week', safetyDays: 9 },
  'AB+': { status: 'Normal', badgeType: 'status-normal', demandIndex: 58, stockTrend: 'Balanced', safetyDays: 12 },
  'AB-': { status: 'Low Stock', badgeType: 'status-low', demandIndex: 82, stockTrend: '-8% this week', safetyDays: 3 },
  'O+': { status: 'High Demand', badgeType: 'status-high', demandIndex: 96, stockTrend: '+25% emergency intake', safetyDays: 3 },
  'O-': { status: 'Low Stock', badgeType: 'status-low', demandIndex: 99, stockTrend: 'Urgent Reserves Only', safetyDays: 1.5 }
};

export const INITIAL_BLOOD_BANKS = [
  {
    id: 'bb-1',
    name: 'City Care Blood Bank',
    badge: 'State Certified Grade A',
    verified: true,
    distanceKm: 2.4,
    address: '45 Health Boulevard, Central Medical District',
    phone: '+1 (555) 234-8901',
    rating: 4.9,
    openHours: '24/7 Emergency Dispatch',
    coldChainCertified: true,
    lastUpdated: '5 minutes ago',
    inventory: {
      'A+': { units: 8, component: 'Packed RBC', lastRefreshed: '5 mins ago' },
      'A-': { units: 3, component: 'Whole Blood', lastRefreshed: '12 mins ago' },
      'B+': { units: 14, component: 'Packed RBC', lastRefreshed: '2 mins ago' },
      'B-': { units: 4, component: 'Whole Blood', lastRefreshed: '25 mins ago' },
      'AB+': { units: 7, component: 'Fresh Frozen Plasma', lastRefreshed: '10 mins ago' },
      'AB-': { units: 2, component: 'Packed RBC', lastRefreshed: '18 mins ago' },
      'O+': { units: 19, component: 'Packed RBC', lastRefreshed: '4 mins ago' },
      'O-': { units: 4, component: 'Whole Blood', lastRefreshed: '15 mins ago' }
    },
    totalAvailable: 61,
    coordinates: { lat: 12.9716, lng: 77.5946 }
  },
  {
    id: 'bb-2',
    name: 'Metro Central Life Bank',
    badge: 'NABH Accredited',
    verified: true,
    distanceKm: 3.8,
    address: '110 Civic Center Way, North Metro',
    phone: '+1 (555) 345-6789',
    rating: 4.8,
    openHours: '24/7 Full Service',
    coldChainCertified: true,
    lastUpdated: '12 minutes ago',
    inventory: {
      'A+': { units: 12, component: 'Packed RBC', lastRefreshed: '12 mins ago' },
      'A-': { units: 2, component: 'Packed RBC', lastRefreshed: '40 mins ago' },
      'B+': { units: 9, component: 'Platelets', lastRefreshed: '8 mins ago' },
      'B-': { units: 3, component: 'Packed RBC', lastRefreshed: '30 mins ago' },
      'AB+': { units: 5, component: 'Fresh Frozen Plasma', lastRefreshed: '15 mins ago' },
      'AB-': { units: 1, component: 'Whole Blood', lastRefreshed: '45 mins ago' },
      'O+': { units: 15, component: 'Packed RBC', lastRefreshed: '6 mins ago' },
      'O-': { units: 3, component: 'Whole Blood', lastRefreshed: '20 mins ago' }
    },
    totalAvailable: 50,
    coordinates: { lat: 12.9822, lng: 77.6012 }
  },
  {
    id: 'bb-3',
    name: 'Apex Hematology Center',
    badge: 'Premier Trauma Partner',
    verified: true,
    distanceKm: 5.1,
    address: '890 BioPark Expressway, South Campus',
    phone: '+1 (555) 456-7890',
    rating: 4.95,
    openHours: '24/7 Emergency Dispatch',
    coldChainCertified: true,
    lastUpdated: '8 minutes ago',
    inventory: {
      'A+': { units: 16, component: 'Packed RBC', lastRefreshed: '8 mins ago' },
      'A-': { units: 5, component: 'Whole Blood', lastRefreshed: '14 mins ago' },
      'B+': { units: 11, component: 'Packed RBC', lastRefreshed: '11 mins ago' },
      'B-': { units: 6, component: 'Packed RBC', lastRefreshed: '19 mins ago' },
      'AB+': { units: 8, component: 'Platelets', lastRefreshed: '7 mins ago' },
      'AB-': { units: 3, component: 'Fresh Frozen Plasma', lastRefreshed: '22 mins ago' },
      'O+': { units: 22, component: 'Packed RBC', lastRefreshed: '3 mins ago' },
      'O-': { units: 6, component: 'Whole Blood', lastRefreshed: '12 mins ago' }
    },
    totalAvailable: 77,
    coordinates: { lat: 12.9555, lng: 77.5811 }
  },
  {
    id: 'bb-4',
    name: 'St. Jude Medical Blood Reserve',
    badge: 'Pediatric & Oncology Specialist',
    verified: true,
    distanceKm: 6.7,
    address: '77 Hope Avenue, West Valley',
    phone: '+1 (555) 567-8901',
    rating: 4.7,
    openHours: '24/7 Operations',
    coldChainCertified: true,
    lastUpdated: '18 minutes ago',
    inventory: {
      'A+': { units: 6, component: 'Platelets', lastRefreshed: '18 mins ago' },
      'A-': { units: 2, component: 'Whole Blood', lastRefreshed: '35 mins ago' },
      'B+': { units: 8, component: 'Packed RBC', lastRefreshed: '22 mins ago' },
      'B-': { units: 2, component: 'Whole Blood', lastRefreshed: '50 mins ago' },
      'AB+': { units: 4, component: 'Fresh Frozen Plasma', lastRefreshed: '14 mins ago' },
      'AB-': { units: 2, component: 'Packed RBC', lastRefreshed: '30 mins ago' },
      'O+': { units: 11, component: 'Packed RBC', lastRefreshed: '10 mins ago' },
      'O-': { units: 2, component: 'Whole Blood', lastRefreshed: '18 mins ago' }
    },
    totalAvailable: 37,
    coordinates: { lat: 12.9644, lng: 77.5688 }
  },
  {
    id: 'bb-5',
    name: 'BlueCross Regional Center',
    badge: 'National Voluntary Hub',
    verified: true,
    distanceKm: 8.2,
    address: '320 Crescent Road, Eastern Hub',
    phone: '+1 (555) 678-9012',
    rating: 4.85,
    openHours: '24/7 Emergency Line',
    coldChainCertified: true,
    lastUpdated: '3 minutes ago',
    inventory: {
      'A+': { units: 14, component: 'Packed RBC', lastRefreshed: '3 mins ago' },
      'A-': { units: 4, component: 'Packed RBC', lastRefreshed: '16 mins ago' },
      'B+': { units: 15, component: 'Packed RBC', lastRefreshed: '9 mins ago' },
      'B-': { units: 5, component: 'Whole Blood', lastRefreshed: '21 mins ago' },
      'AB+': { units: 9, component: 'Cryoprecipitate', lastRefreshed: '2 mins ago' },
      'AB-': { units: 3, component: 'Fresh Frozen Plasma', lastRefreshed: '11 mins ago' },
      'O+': { units: 24, component: 'Packed RBC', lastRefreshed: '1 min ago' },
      'O-': { units: 5, component: 'Whole Blood', lastRefreshed: '17 mins ago' }
    },
    totalAvailable: 79,
    coordinates: { lat: 12.9899, lng: 77.6255 }
  }
];

export const INITIAL_REQUESTS = [
  {
    id: 'REQ-8821',
    patientName: 'David Miller',
    hospitalName: 'Mercy General Hospital - Trauma ICU',
    bloodGroup: 'O-',
    units: 2,
    component: 'Whole Blood',
    urgency: 'EMERGENCY',
    reason: 'Acute post-operative hemorrhage',
    bloodBankId: 'bb-1',
    bloodBankName: 'City Care Blood Bank',
    requestedTime: '22 minutes ago',
    stageIndex: 4, // 0: REQUESTED, 1: VERIFICATION, 2: APPROVED, 3: BLOOD PACKED, 4: OUT FOR DELIVERY, 5: DELIVERED
    status: 'OUT FOR DELIVERY',
    courierName: 'Vikram Joshi (Cold-Chain Unit #14)',
    courierPhone: '+1 (555) 908-1122',
    courierVehicle: 'Temperature-Monitored EV Van #B-404',
    boxTemperature: '3.6°C (Optimal Safe 2-6°C)',
    etaMinutes: 12,
    distanceRemainingKm: 1.8,
    verificationCode: 'BL-9824',
    timeline: [
      { step: 'REQUESTED', time: '10:05 AM', done: true, note: 'Emergency request initiated by Dr. Sarah Jenkins' },
      { step: 'VERIFICATION', time: '10:07 AM', done: true, note: 'Cross-match digital record verified by Blood Bank' },
      { step: 'APPROVED', time: '10:09 AM', done: true, note: 'Approved by Senior Hematologist Marcus Vance' },
      { step: 'BLOOD PACKED', time: '10:14 AM', done: true, note: 'Sealed in thermal transit container at 3.6°C' },
      { step: 'OUT FOR DELIVERY', time: '10:19 AM', done: true, note: 'Courier Vikram Joshi dispatched with live telemetry' },
      { step: 'DELIVERED', time: 'Pending (ETA 12m)', done: false, note: 'Awaiting hospital receiving ward confirmation' }
    ]
  },
  {
    id: 'REQ-8819',
    patientName: 'Anita Sharma',
    hospitalName: 'City Children\'s Hospital - Hematology Wing',
    bloodGroup: 'B+',
    units: 1,
    component: 'Platelets',
    urgency: 'HIGH',
    reason: 'Thrombocytopenia platelet transfusion',
    bloodBankId: 'bb-3',
    bloodBankName: 'Apex Hematology Center',
    requestedTime: '45 minutes ago',
    stageIndex: 3,
    status: 'BLOOD PACKED',
    courierName: 'Priya Sundaram (Rapid Fleet #07)',
    courierPhone: '+1 (555) 789-2234',
    courierVehicle: 'Secure Cryo-Pod #CP-12',
    boxTemperature: '22.1°C (Agitated room temp for platelets)',
    etaMinutes: 24,
    distanceRemainingKm: 3.5,
    verificationCode: 'BL-4412',
    timeline: [
      { step: 'REQUESTED', time: '09:40 AM', done: true, note: 'Request logged by Pediatric Ward Nurse' },
      { step: 'VERIFICATION', time: '09:44 AM', done: true, note: 'Donor serology profile double-checked' },
      { step: 'APPROVED', time: '09:48 AM', done: true, note: 'Batch released for transfer' },
      { step: 'BLOOD PACKED', time: '09:55 AM', done: true, note: 'Packaged in agitation-safe insulated box' },
      { step: 'OUT FOR DELIVERY', time: 'Pending Courier Pickup', done: false, note: 'Courier arriving at blood bank dock' },
      { step: 'DELIVERED', time: 'Pending', done: false, note: 'Pending delivery handover' }
    ]
  },
  {
    id: 'REQ-8810',
    patientName: 'Robert Langdon',
    hospitalName: 'St. Luke Cardiovascular Institute',
    bloodGroup: 'A+',
    units: 3,
    component: 'Packed RBC',
    urgency: 'STANDARD',
    reason: 'Scheduled bypass graft replacement',
    bloodBankId: 'bb-2',
    bloodBankName: 'Metro Central Life Bank',
    requestedTime: '2 hours ago',
    stageIndex: 5,
    status: 'DELIVERED',
    courierName: 'Arjun Das (Courier Unit #03)',
    courierPhone: '+1 (555) 443-8899',
    courierVehicle: 'Insulated Medical Courier Bike #09',
    boxTemperature: '4.1°C (Safe handover certified)',
    etaMinutes: 0,
    distanceRemainingKm: 0,
    verificationCode: 'BL-1108',
    timeline: [
      { step: 'REQUESTED', time: '08:15 AM', done: true, note: 'Scheduled surgical reservation' },
      { step: 'VERIFICATION', time: '08:22 AM', done: true, note: 'Blood group and crossmatch confirmed' },
      { step: 'APPROVED', time: '08:30 AM', done: true, note: 'Released from reserved inventory' },
      { step: 'BLOOD PACKED', time: '08:45 AM', done: true, note: 'Dual-seal temperature barcoded pack' },
      { step: 'OUT FOR DELIVERY', time: '09:05 AM', done: true, note: 'Dispatched via express transit route' },
      { step: 'DELIVERED', time: '09:32 AM', done: true, note: 'Received & confirmed by Head Nurse Jackson' }
    ]
  }
];

export const INITIAL_DONORS = [
  {
    id: 'DON-101',
    name: 'Karan Patel',
    bloodGroup: 'O-',
    age: 28,
    gender: 'Male',
    lastDonationDate: '2026-06-14',
    totalDonations: 6,
    eligibilityStatus: 'Eligible Today',
    city: 'Central District',
    phone: '+1 (555) 782-3901'
  },
  {
    id: 'DON-102',
    name: 'Meera Rao',
    bloodGroup: 'A+',
    age: 24,
    gender: 'Female',
    lastDonationDate: '2026-08-02',
    totalDonations: 3,
    eligibilityStatus: 'Eligible in 18 days',
    city: 'North Metro',
    phone: '+1 (555) 912-4412'
  },
  {
    id: 'DON-103',
    name: 'Samuel Thomas',
    bloodGroup: 'B+',
    age: 32,
    gender: 'Male',
    lastDonationDate: '2026-05-19',
    totalDonations: 11,
    eligibilityStatus: 'Eligible Today',
    city: 'South Campus',
    phone: '+1 (555) 604-5578'
  }
];

export const HOSPITALS_LIST = [
  {
    id: 'HOSP-1',
    name: 'Mercy General Hospital',
    type: 'Tertiary Trauma Center',
    address: '100 Mercy Circle, Central District',
    contact: '+1 (555) 911-0010',
    emergencyDesk: 'ER Desk Ext 201',
    affiliatedBanks: ['City Care Blood Bank', 'Apex Hematology Center'],
    dailyUnitsNeeded: 18,
    liveStatus: 'Active Emergency Requisitions Open'
  },
  {
    id: 'HOSP-2',
    name: 'City Children\'s Hospital',
    type: 'Pediatric Specialty',
    address: '42 Blossom Way, North District',
    contact: '+1 (555) 911-0022',
    emergencyDesk: 'Pediatric ICU Desk 104',
    affiliatedBanks: ['Metro Central Life Bank', 'St. Jude Medical Blood Reserve'],
    dailyUnitsNeeded: 9,
    liveStatus: 'Normal Intake'
  },
  {
    id: 'HOSP-3',
    name: 'St. Luke Cardiovascular Institute',
    type: 'Heart & Vascular Specialty',
    address: '500 St. Luke Plaza, Metro East',
    contact: '+1 (555) 911-0033',
    emergencyDesk: 'OR Blood Bank Desk 305',
    affiliatedBanks: ['BlueCross Regional Center', 'City Care Blood Bank'],
    dailyUnitsNeeded: 14,
    liveStatus: 'Cardiac Surgeries Scheduled'
  },
  {
    id: 'HOSP-4',
    name: 'Apex Super Specialty Hospital',
    type: 'Oncology & Multi-Organ Transplant',
    address: '880 Healthway Parkway, South Metro',
    contact: '+1 (555) 911-0044',
    emergencyDesk: 'Transplant OR Liaison 401',
    affiliatedBanks: ['Apex Hematology Center', 'Metro Central Life Bank'],
    dailyUnitsNeeded: 22,
    liveStatus: 'Critical Platelet Requisitions Active'
  }
];

export const ROLE_PROFILES = {
  patient: {
    key: 'patient',
    title: 'Patient / Hospital Requester',
    name: 'Dr. Sarah Jenkins',
    facility: 'Mercy General Hospital — Emergency ICU',
    roleLabel: 'Medical Requester',
    avatarText: 'SJ',
    permissions: ['Search Blood', 'Place Standard & Emergency Requests', 'Live GPS Tracking', 'Medical History']
  },
  bloodbank: {
    key: 'bloodbank',
    title: 'Blood Bank Administrator',
    name: 'Marcus Vance',
    facility: 'City Care Blood Bank (Central Medical Dist)',
    roleLabel: 'Senior Hematologist & Bank Manager',
    avatarText: 'MV',
    permissions: ['Live Inventory Management', 'Verify & Approve Requests', 'Cold-Chain Dispatch Packaging', 'Assign Fleet Couriers']
  },
  delivery: {
    key: 'delivery',
    title: 'Delivery Staff / Fleet Agent',
    name: 'Vikram Joshi',
    facility: 'BloodPulse Cold-Chain Rapid Fleet Unit #14',
    roleLabel: 'Certified Medical Transit Specialist',
    avatarText: 'VJ',
    permissions: ['Assigned Deliveries Queue', 'Update Status (Packed -> In Transit -> Delivered)', 'Monitor Cold-Box Sensor', 'OTP Handover Signoff']
  },
  admin: {
    key: 'admin',
    title: 'Master System Admin',
    name: 'Elena Rostova',
    facility: 'State Health Authority & Network Control',
    roleLabel: 'Central Health Ops Supervisor',
    avatarText: 'ER',
    permissions: ['System Overview', 'Verify Blood Banks', 'ML Demand Predictions & Stock Reserves', 'Network Audit Logs']
  }
};
